import { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams } from "expo-router";
import { FileText, Star, BookOpen, CheckCircle2 } from "lucide-react-native";
import { auth } from "../../utils/firebase/config";
import { getParentAccess, loadTeacherStore } from "../../utils/firebase/roles";
import { useT } from "../../utils/i18n";

const pad = (n) => String(n).padStart(2, "0");
function formatDateFull(s, monthsArr) {
  if (!s) return "";
  const [y, m, d] = s.split("-").map(Number);
  return `${d} ${monthsArr[m - 1]} ${y}`;
}

function ReportDetail({ report, onClose }) {
  const { t, months } = useT();
  const monthsFull = months(false);
  const SCORE_CFG = {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2" },
  };
  const cfg = SCORE_CFG[report.activityScore] ?? SCORE_CFG[3];
  const sections = [
    { titleKey: "reportSectionStrengths", value: report.strengths, color: "#22C55E", bg: "#F0FDF4" },
    { titleKey: "reportSectionDifficulties", value: report.difficulties, color: "#F59E0B", bg: "#FFFBEB" },
    { titleKey: "childHW", value: report.homework, color: "#6B5CF6", bg: "#EEF0FF" },
    { titleKey: "reportSectionNextPlan", value: report.nextLessonPlan, color: "#0EA5E9", bg: "#E0F2FE" },
    { titleKey: "reportSectionComment", value: report.comment, color: "#3B82F6", bg: "#EFF6FF" },
  ];
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#F2F2F7" }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ backgroundColor: "#FFFFFF", borderRadius: 0, padding: 20, marginBottom: 8 }}>
        <TouchableOpacity onPress={onClose} style={{ marginBottom: 16 }}>
          <Text style={{ fontSize: 14, fontFamily: "Inter_500Medium", color: "#0EA5E9" }}>{t("parentReportsBack")}</Text>
        </TouchableOpacity>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 }}>
          <View style={{ paddingHorizontal: 10, paddingVertical: 4, backgroundColor: cfg.bg, borderRadius: 20 }}>
            <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: cfg.color }}>{cfg.label}</Text>
          </View>
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
            {report.subject}
          </Text>
        </View>
        <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginBottom: 4 }}>
          {report.topic}
        </Text>
        <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#8E8E93", marginBottom: 16 }}>
          {formatDateFull(report.date, monthsFull)} · {report.studentName}
        </Text>
        <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#3C3C43", lineHeight: 22 }}>
          {report.description}
        </Text>
      </View>

      {sections.filter(s => s.value).map(({ titleKey, value, color, bg }) => (
        <View key={titleKey} style={{ backgroundColor: "#FFFFFF", borderRadius: 16, padding: 16, marginHorizontal: 0, marginBottom: 8 }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color, marginBottom: 8 }}>{t(titleKey)}</Text>
          <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#3C3C43", lineHeight: 22 }}>{value}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

export default function ParentReports() {
  const insets = useSafeAreaInsets();
  const { highlight } = useLocalSearchParams();
  const { t, months } = useT();
  const monthsFull = months(false);

  const SCORE_CFG = {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2" },
  };

  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState([]);
  const [children, setChildren] = useState([]);
  const [filterStudentId, setFilterStudentId] = useState(highlight ?? null);
  const [selectedReport, setSelectedReport] = useState(null);

  const uid = auth?.currentUser?.uid;

  useEffect(() => {
    if (!uid) { setLoading(false); return; }
    loadData();
  }, [uid]);

  const loadData = async () => {
    setLoading(true);
    try {
      const links = await getParentAccess(uid);
      const allRep = [];
      const allStudents = [];

      await Promise.all(
        links.map(async ({ teacherUid, studentIds }) => {
          const [studs, reps] = await Promise.all([
            loadTeacherStore(teacherUid, "students"),
            loadTeacherStore(teacherUid, "reports"),
          ]);
          const allowed = new Set(studentIds.map(String));
          if (studs) allStudents.push(...studs.filter((s) => allowed.has(String(s.id))));
          if (reps) allRep.push(...reps.filter((r) => allowed.has(String(r.studentId))));
        })
      );

      setChildren(allStudents);
      setReports(allRep.sort((a, b) => b.createdAt - a.createdAt));
    } finally {
      setLoading(false);
    }
  };

  if (selectedReport) {
    return (
      <View style={{ flex: 1, paddingTop: insets.top }}>
        <ReportDetail report={selectedReport} onClose={() => setSelectedReport(null)} />
      </View>
    );
  }

  const filtered = filterStudentId
    ? reports.filter((r) => String(r.studentId) === String(filterStudentId))
    : reports;

  return (
    <View style={{ flex: 1, backgroundColor: "#F2F2F7" }}>
      {/* Header */}
      <View
        style={{
          backgroundColor: "#FFFFFF",
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 16,
          shadowColor: "#000",
          shadowOpacity: 0.04,
          shadowRadius: 8,
          elevation: 2,
        }}
      >
        <Text style={{ fontSize: 28, fontFamily: "Inter_700Bold", color: "#1C1C1E", letterSpacing: -0.5 }}>
          {t("reportsTitle")}
        </Text>

        {/* Student filter chips */}
        {children.length > 1 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12 }}>
            <View style={{ flexDirection: "row", gap: 8 }}>
              <TouchableOpacity
                onPress={() => setFilterStudentId(null)}
                style={{
                  paddingHorizontal: 14,
                  paddingVertical: 6,
                  borderRadius: 20,
                  backgroundColor: !filterStudentId ? "#0EA5E9" : "#F2F2F7",
                }}
              >
                <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: !filterStudentId ? "#FFFFFF" : "#8E8E93" }}>
                  {t("all")}
                </Text>
              </TouchableOpacity>
              {children.map((c) => (
                <TouchableOpacity
                  key={c.id}
                  onPress={() => setFilterStudentId(filterStudentId === String(c.id) ? null : String(c.id))}
                  style={{
                    paddingHorizontal: 14,
                    paddingVertical: 6,
                    borderRadius: 20,
                    backgroundColor: filterStudentId === String(c.id) ? "#0EA5E9" : "#F2F2F7",
                  }}
                >
                  <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: filterStudentId === String(c.id) ? "#FFFFFF" : "#8E8E93" }}>
                    {c.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        )}
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color="#0EA5E9" />
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 32 }}>
          {filtered.length === 0 ? (
            <View style={{ backgroundColor: "#FFFFFF", borderRadius: 20, padding: 40, alignItems: "center" }}>
              <FileText size={32} color="#C7C7CC" />
              <Text style={{ fontSize: 15, fontFamily: "Inter_500Medium", color: "#8E8E93", marginTop: 14, textAlign: "center" }}>
                {t("parentReportsEmpty")}
              </Text>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {filtered.map((report) => {
                const cfg = SCORE_CFG[report.activityScore] ?? SCORE_CFG[3];
                return (
                  <TouchableOpacity
                    key={report.id}
                    activeOpacity={0.82}
                    onPress={() => setSelectedReport(report)}
                    style={{
                      backgroundColor: "#FFFFFF",
                      borderRadius: 16,
                      padding: 16,
                      borderLeftWidth: 3,
                      borderLeftColor: cfg.color,
                      shadowColor: "#000",
                      shadowOpacity: 0.04,
                      shadowRadius: 8,
                      elevation: 2,
                    }}
                  >
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 5 }}>
                      <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
                        {report.studentName}
                      </Text>
                      <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                        <Star size={11} color={cfg.color} fill={cfg.color} />
                        <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: cfg.color }}>
                          {cfg.label}
                        </Text>
                      </View>
                    </View>
                    <Text style={{ fontSize: 14, fontFamily: "Inter_500Medium", color: "#3C3C43", marginBottom: 5 }} numberOfLines={1}>
                      {report.topic}
                    </Text>
                    <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
                      {formatDateFull(report.date, monthsFull)} · {report.subject}
                    </Text>
                    {report.homework ? (
                      <View style={{ marginTop: 8, flexDirection: "row", alignItems: "flex-start", gap: 6, backgroundColor: "#EEF0FF", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7 }}>
                        <BookOpen size={12} color="#6B5CF6" style={{ marginTop: 2 }} />
                        <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#6B5CF6", flex: 1 }} numberOfLines={2}>
                          {t("hwAbbr")}: {report.homework}
                        </Text>
                      </View>
                    ) : null}
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
