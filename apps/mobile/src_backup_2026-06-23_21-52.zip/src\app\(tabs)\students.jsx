import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState, useMemo } from "react";
import { useRouter } from "expo-router";
import {
  UserPlus, Search, X, GraduationCap,
  CalendarDays, ChevronRight, Plus,
} from "lucide-react-native";
import { useStudentsStore } from "@/utils/students/store";
import { useProgressStore } from "@/utils/progress/store";
import { useLessonsStore } from "@/utils/lessons/store";
import { useGroupsStore } from "@/utils/groups/store";
import { useVipStore, FREE_LIMIT } from "@/utils/vip/store";
import AddStudentModal from "@/components/AddStudentModal";
import GroupsView from "@/components/GroupsView";
import VipPaywallModal from "@/components/VipPaywallModal";
import { useT } from "@/utils/i18n";

// ─── tokens ──────────────────────────────────────────────────────────────────
const C = {
  primary: "#5B4FE9",
  bg:      "#FAFAFA",
  card:    "#FFFFFF",
  text:    "#111827",
  sub:     "#9CA3AF",
  border:  "#F3F4F6",
  green:   "#10B981",
  amber:   "#F59E0B",
  red:     "#EF4444",
};

// ─── helpers ─────────────────────────────────────────────────────────────────
const pad = (n) => String(n).padStart(2, "0");
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function tomorrowStr() {
  const d = new Date(); d.setDate(d.getDate() + 1);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function scoreColor(s) {
  if (s >= 9) return "#10B981";
  if (s >= 8) return "#3B82F6";
  if (s >= 7) return "#F59E0B";
  if (s > 0)  return "#EF4444";
  return C.sub;
}

const PALETTE = [C.primary,"#10B981","#F59E0B","#EF4444","#06B6D4","#8B5CF6","#EC4899","#0EA5E9"];
function avatarBg(name = "", override) {
  if (override) return override;
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffff;
  return PALETTE[h % PALETTE.length];
}
function initials(name = "") {
  const p = name.trim().split(/\s+/);
  return (p.length >= 2 ? p[0][0] + p[1][0] : name.slice(0, 2)).toUpperCase();
}
function plur(n, one = "ученик", few = "ученика", many = "учеников") {
  if (n % 10 === 1 && n % 100 !== 11) return one;
  if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) return few;
  return many;
}

function getStudentNextLesson(lessons, studentId, todayLabel, tomorrowLabel, shortMonths) {
  const today    = todayStr();
  const tomorrow = tomorrowStr();
  const now      = new Date();
  const nowMin   = now.getHours() * 60 + now.getMinutes();
  const upcoming = lessons
    .filter(l =>
      l.status !== "completed" && l.status !== "cancelled" &&
      l.studentIds?.includes(studentId) && l.date &&
      (l.date > today || (l.date === today && (() => {
        const [h, m] = (l.time ?? "00:00").split(":").map(Number);
        return h * 60 + m > nowMin;
      })()))
    )
    .sort((a, b) => `${a.date} ${a.time ?? ""}`.localeCompare(`${b.date} ${b.time ?? ""}`));
  const l = upcoming[0];
  if (!l) return null;
  const day = l.date === today ? todayLabel : l.date === tomorrow ? tomorrowLabel : (() => {
    const [, mo, d] = l.date.split("-").map(Number);
    return `${d} ${shortMonths[mo - 1]}`;
  })();
  return { label: l.time ? `${day}, ${l.time}` : day, date: l.date };
}

// ─── Student carousel card (mirrors GroupCard) ────────────────────────────────
function StudentCarouselCard({ student, score, onPress }) {
  const bg    = avatarBg(student.name, student.avatarColor);
  const sColor = scoreColor(score);
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.84}
      style={{
        width: 148,
        backgroundColor: C.card,
        borderRadius: 20,
        paddingTop: 18,
        paddingBottom: 16,
        paddingHorizontal: 14,
        alignItems: "center",
        shadowColor: "#000",
        shadowOpacity: 0.07,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 3 },
        elevation: 4,
      }}
    >
      {/* Avatar circle */}
      <View style={{
        width: 72, height: 72, borderRadius: 36,
        backgroundColor: bg,
        alignItems: "center", justifyContent: "center",
        marginBottom: 10,
      }}>
        <Text style={{ fontSize: 24, fontFamily: "Inter_700Bold", color: "#FFF", letterSpacing: 0.5 }}>
          {initials(student.name)}
        </Text>
      </View>
      {/* Name */}
      <Text
        numberOfLines={2}
        style={{ fontSize: 13, fontFamily: "Inter_700Bold", color: C.text, textAlign: "center", lineHeight: 18, marginBottom: 4 }}
      >
        {student.name}
      </Text>
      {/* Type */}
      {student.type ? (
        <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: C.sub, marginBottom: 6 }}>
          {student.type}
        </Text>
      ) : <View style={{ height: 18 }} />}
      {/* Score */}
      <Text style={{ fontSize: 16, fontFamily: "Inter_700Bold", color: score > 0 ? sColor : C.sub }}>
        {score > 0 ? `${score.toFixed(1)}/10` : "—"}
      </Text>
    </TouchableOpacity>
  );
}

// ─── Student list row (mirrors GroupRow) ──────────────────────────────────────
function StudentRow({ student, score, nextLesson, onPress, showBorder }) {
  const bg     = avatarBg(student.name, student.avatarColor);
  const sColor = scoreColor(score);
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.75}
      style={{
        flexDirection: "row", alignItems: "center", gap: 12,
        paddingHorizontal: 16, paddingVertical: 15,
        borderBottomWidth: showBorder ? 1 : 0,
        borderBottomColor: C.border,
      }}
    >
      {/* Avatar */}
      <View style={{
        width: 52, height: 52, borderRadius: 26,
        backgroundColor: bg,
        alignItems: "center", justifyContent: "center",
      }}>
        <Text style={{ fontSize: 17, fontFamily: "Inter_700Bold", color: "#FFF" }}>
          {initials(student.name)}
        </Text>
      </View>
      {/* Info */}
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: C.text, marginBottom: 3 }}>
          {student.name}
        </Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
          {student.type ? (
            <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: C.sub }}>
              {student.type}
            </Text>
          ) : null}
          {nextLesson && (
            <>
              {student.type && <Text style={{ fontSize: 12, color: C.border }}>·</Text>}
              <CalendarDays size={11} color={C.sub} strokeWidth={2} />
              <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: C.sub }} numberOfLines={1}>
                {nextLesson.label}
              </Text>
            </>
          )}
        </View>
      </View>
      {/* Score */}
      <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: score > 0 ? sColor : C.sub, marginRight: 4 }}>
        {score > 0 ? `${score.toFixed(1)}/10` : "—"}
      </Text>
      <ChevronRight size={16} color={C.sub} strokeWidth={2} />
    </TouchableOpacity>
  );
}

// ─── Empty states ─────────────────────────────────────────────────────────────
function EmptyStudents({ onAdd }) {
  const { t } = useT();
  return (
    <View style={{ alignItems: "center", paddingTop: 60, paddingHorizontal: 40 }}>
      <View style={{ width: 88, height: 88, borderRadius: 28, backgroundColor: `${C.primary}10`, alignItems: "center", justifyContent: "center", marginBottom: 22 }}>
        <GraduationCap size={40} color={C.primary} strokeWidth={1.4} />
      </View>
      <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: C.text, marginBottom: 10, textAlign: "center" }}>
        {t("studentsEmptyTitle")}
      </Text>
      <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: C.sub, textAlign: "center", lineHeight: 22, marginBottom: 32 }}>
        {t("studentsEmptyHint")}
      </Text>
      <TouchableOpacity onPress={onAdd} activeOpacity={0.85} style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: C.primary, paddingHorizontal: 28, paddingVertical: 14, borderRadius: 16 }}>
        <UserPlus size={18} color="#FFF" />
        <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: "#FFF" }}>{t("studentsAddBtn")}</Text>
      </TouchableOpacity>
    </View>
  );
}

function EmptySearch({ q }) {
  const { t } = useT();
  return (
    <View style={{ alignItems: "center", paddingTop: 56, paddingHorizontal: 40 }}>
      <Text style={{ fontSize: 36, marginBottom: 16 }}>🔍</Text>
      <Text style={{ fontSize: 17, fontFamily: "Inter_600SemiBold", color: C.text, marginBottom: 6 }}>{t("noResults")}</Text>
      <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: C.sub, textAlign: "center" }}>
        {t("studentsNoResults", { q })}
      </Text>
    </View>
  );
}


// ─── Main ─────────────────────────────────────────────────────────────────────
export default function StudentsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t, tp, months } = useT();

  const [mainTab,      setMainTab]      = useState("students"); // "students" | "groups"
  const [search,       setSearch]       = useState("");
  const [showSearch,      setShowSearch]      = useState(false);
  const [showAdd,         setShowAdd]         = useState(false);
  const [showAddGroup,    setShowAddGroup]    = useState(false);
  const [showPaywall,     setShowPaywall]     = useState(false);

  const { students }    = useStudentsStore();
  const { evaluations } = useProgressStore();
  const { lessons }     = useLessonsStore();
  const { groups }      = useGroupsStore();
  const { isVip }       = useVipStore();

  const today = todayStr();

  const shortMonths = months(true);
  const todayLabel    = t("today");
  const tomorrowLabel = t("tomorrow");

  const enriched = useMemo(() =>
    students.map(s => {
      const evs  = evaluations.filter(e => e.studentId === s.id).sort((a, b) => b.createdAt - a.createdAt);
      const last  = evs[0];
      const score = last ? ((last.activity + last.comprehension + last.homework + last.behavior) / 4) * 2 : 0;
      const next  = getStudentNextLesson(lessons, s.id, todayLabel, tomorrowLabel, shortMonths);
      return { ...s, _score: score, _next: next };
    }),
    [students, evaluations, lessons, todayLabel, tomorrowLabel, shortMonths],
  );

  // Students with lessons today (for carousel)
  const todayStudents = useMemo(() =>
    lessons
      .filter(l => l.date === today && l.status !== "cancelled")
      .flatMap(l => (l.studentIds ?? []).map(id => ({ id, time: l.time })))
      .reduce((acc, { id }) => {
        if (!acc.some(x => x.id === id)) {
          const s = enriched.find(s => s.id === id);
          if (s) acc.push(s);
        }
        return acc;
      }, []),
    [lessons, today, enriched],
  );

  // Filtered list (respects search)
  const displayed = useMemo(() => {
    if (!search) return enriched;
    const q = search.toLowerCase();
    return enriched.filter(s => s.name.toLowerCase().includes(q));
  }, [enriched, search]);

  const avgScore = useMemo(() => {
    const s = enriched.filter(x => x._score > 0);
    return s.length ? s.reduce((a, x) => a + x._score, 0) / s.length : 0;
  }, [enriched]);

  function openAddStudent() {
    if (students.length >= FREE_LIMIT && !isVip) setShowPaywall(true);
    else setShowAdd(true);
  }

  function handlePlusPress() {
    if (mainTab === "students") openAddStudent();
    else setShowAddGroup(true);
  }

  function switchMain(tab) {
    setMainTab(tab);
    if (tab === "groups") { setShowSearch(false); setSearch(""); }
  }

  return (
    <>
      <View style={{ flex: 1, backgroundColor: C.bg }}>
        {/* ══ SHARED HEADER ════════════════════════════════════════════ */}
        <View style={{
          backgroundColor: C.card,
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 0,
          borderBottomWidth: 1,
          borderBottomColor: C.border,
        }}>
          {/* Title row */}
          <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 2 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 28, fontFamily: "Inter_700Bold", color: C.text, letterSpacing: -0.5 }}>
                {mainTab === "students" ? t("studentsTitle") : t("studentsGroups")}
              </Text>
              {mainTab === "students" && (
                <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: C.sub, marginTop: 2 }}>
                  {students.length} {tp(students.length, "student")}
                  {avgScore > 0 && (
                    <>
                      {" · " + t("studentsAvgScore") + " "}
                      <Text style={{ fontFamily: "Inter_600SemiBold", color: avgScore >= 8 ? "#10B981" : avgScore >= 6 ? "#F59E0B" : C.sub }}>
                        {avgScore.toFixed(1)}
                      </Text>
                    </>
                  )}
                </Text>
              )}
              {mainTab === "groups" && (
                <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: C.sub, marginTop: 2 }}>
                  {groups.length} {tp(groups.length, "group")}
                </Text>
              )}
            </View>

            <View style={{ flexDirection: "row", gap: 10 }}>
              {mainTab === "students" && (
                <TouchableOpacity
                  onPress={() => { setShowSearch(v => !v); if (showSearch) setSearch(""); }}
                  activeOpacity={0.7}
                  style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: showSearch ? `${C.primary}12` : C.border, alignItems: "center", justifyContent: "center" }}
                >
                  {showSearch
                    ? <X size={18} color={C.primary} strokeWidth={2.5} />
                    : <Search size={18} color={C.sub} strokeWidth={2} />
                  }
                </TouchableOpacity>
              )}
              <View style={{ alignItems: "center" }}>
                <TouchableOpacity
                  onPress={handlePlusPress}
                  activeOpacity={0.8}
                  style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: C.primary, alignItems: "center", justifyContent: "center" }}
                >
                  <Plus size={20} color="#FFF" strokeWidth={2.5} />
                </TouchableOpacity>
                {mainTab === "students" && !isVip && students.length > 0 && (
                  <Text style={{ fontSize: 10, fontFamily: "Inter_500Medium", color: students.length >= FREE_LIMIT ? "#EF4444" : C.sub, marginTop: 2 }}>
                    {students.length}/{FREE_LIMIT}
                  </Text>
                )}
              </View>
            </View>
          </View>

          {/* Search bar */}
          {mainTab === "students" && showSearch && (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: C.bg, borderRadius: 13, paddingHorizontal: 14, height: 44, marginTop: 12 }}>
              <Search size={16} color={C.sub} strokeWidth={2} />
              <TextInput
                autoFocus
                value={search}
                onChangeText={setSearch}
                placeholder={t("studentsSearchHint")}
                placeholderTextColor={C.sub}
                style={{ flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", color: C.text }}
              />
              {search.length > 0 && (
                <TouchableOpacity onPress={() => setSearch("")}>
                  <X size={15} color={C.sub} strokeWidth={2} />
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* Main tab toggle */}
          <View style={{ flexDirection: "row", marginTop: 14 }}>
            {[
              { id: "students", label: t("studentsTitle") },
              { id: "groups",   label: t("studentsGroups") },
            ].map(({ id, label }) => {
              const active = mainTab === id;
              return (
                <TouchableOpacity
                  key={id}
                  onPress={() => switchMain(id)}
                  activeOpacity={0.7}
                  style={{ flex: 1, paddingBottom: 12, alignItems: "center", position: "relative" }}
                >
                  <Text style={{ fontSize: 14, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular", color: active ? C.primary : C.sub }}>
                    {label}
                  </Text>
                  {active && (
                    <View style={{ position: "absolute", bottom: 0, left: 20, right: 20, height: 2.5, borderRadius: 1.5, backgroundColor: C.primary }} />
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* ══ STUDENTS VIEW ════════════════════════════════════════════ */}
        {mainTab === "students" && (
          <ScrollView
            style={{ flex: 1 }}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
            keyboardShouldPersistTaps="handled"
          >
            {students.length === 0 ? (
              <EmptyStudents onAdd={openAddStudent} />
            ) : (
              <>
                {/* ── Уроки сегодня (carousel) ──────────────────── */}
                {!search && todayStudents.length > 0 && (
                  <View style={{ marginBottom: 28 }}>
                    <View style={{ paddingHorizontal: 20, paddingTop: 22, paddingBottom: 14 }}>
                      <Text style={{ fontSize: 17, fontFamily: "Inter_700Bold", color: C.text }}>
                        {t("studentsTodayLessons")}{" "}
                        <Text style={{ fontFamily: "Inter_400Regular", color: C.sub, fontSize: 15 }}>
                          ({todayStudents.length})
                        </Text>
                      </Text>
                    </View>
                    <ScrollView
                      horizontal
                      showsHorizontalScrollIndicator={false}
                      contentContainerStyle={{ paddingHorizontal: 20, gap: 14 }}
                    >
                      {todayStudents.map(s => (
                        <StudentCarouselCard
                          key={s.id}
                          student={s}
                          score={s._score}
                          onPress={() => router.push(`/student/${s.id}`)}
                        />
                      ))}
                    </ScrollView>
                  </View>
                )}

                {/* ── Все ученики (list) ─────────────────────────── */}
                <View style={{ paddingHorizontal: 20, paddingTop: search ? 20 : 0 }}>
                  {displayed.length === 0 ? (
                    <EmptySearch q={search} />
                  ) : (
                    <>
                      <Text style={{ fontSize: 17, fontFamily: "Inter_700Bold", color: C.text, marginBottom: 14 }}>
                        {search ? t("studentsSearchResults") : t("studentsAllStudents")}{" "}
                        <Text style={{ fontFamily: "Inter_400Regular", color: C.sub, fontSize: 15 }}>
                          ({displayed.length})
                        </Text>
                      </Text>
                      <View style={{
                        backgroundColor: C.card,
                        borderRadius: 18,
                        overflow: "hidden",
                        shadowColor: "#000",
                        shadowOpacity: 0.06,
                        shadowRadius: 10,
                        shadowOffset: { width: 0, height: 2 },
                        elevation: 3,
                        marginBottom: 16,
                      }}>
                        {displayed.map((s, i) => (
                          <StudentRow
                            key={s.id}
                            student={s}
                            score={s._score}
                            nextLesson={s._next}
                            onPress={() => router.push(`/student/${s.id}`)}
                            showBorder={i < displayed.length - 1}
                          />
                        ))}
                      </View>

                      {/* Add student row */}
                      <TouchableOpacity
                        onPress={openAddStudent}
                        activeOpacity={0.75}
                        style={{
                          flexDirection: "row", alignItems: "center", gap: 14,
                          backgroundColor: C.card,
                          borderRadius: 18, paddingHorizontal: 16, paddingVertical: 15,
                          borderWidth: 1.5, borderColor: `${C.primary}20`, borderStyle: "dashed",
                        }}
                      >
                        <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: `${C.primary}10`, alignItems: "center", justifyContent: "center" }}>
                          <UserPlus size={22} color={C.primary} strokeWidth={2} />
                        </View>
                        <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: C.primary }}>
                          {t("studentsAddBtn")}
                        </Text>
                      </TouchableOpacity>
                    </>
                  )}
                </View>
              </>
            )}
          </ScrollView>
        )}

        {/* ══ GROUPS VIEW ══════════════════════════════════════════════ */}
        {mainTab === "groups" && (
          <GroupsView
            bottomInset={insets.bottom}
            showAddModal={showAddGroup}
            onCloseAddModal={() => setShowAddGroup(false)}
          />
        )}
      </View>

      <AddStudentModal visible={showAdd} onClose={() => setShowAdd(false)} />
      <VipPaywallModal
        visible={showPaywall}
        onClose={() => setShowPaywall(false)}
        onUpgraded={() => { setShowPaywall(false); setShowAdd(true); }}
      />
    </>
  );
}
