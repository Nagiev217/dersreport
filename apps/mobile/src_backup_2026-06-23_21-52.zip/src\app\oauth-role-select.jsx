import { useState } from "react";
import {
  View, Text, TouchableOpacity, ActivityIndicator,
  StatusBar, Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { GraduationCap, Users, ChevronRight, Sparkles } from "lucide-react-native";
import { auth } from "@/utils/firebase/config";
import { registerTeacher, registerParent } from "@/utils/firebase/users";
import { registerPushToken } from "@/utils/firebase/notifications";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useT } from "@/utils/i18n";

export default function OAuthRoleSelectScreen() {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(null);
  const { t } = useT();

  const ROLES = [
    {
      key: "teacher",
      icon: GraduationCap,
      titleKey: "roleTeacherTitle",
      subtitleKey: "oauthTeacherSubtitle",
      featureKeys: ["roleTeacherF1", "roleTeacherF2", "roleTeacherF3"],
      gradient: ["#4F46E5", "#6B5CF6"],
    },
    {
      key: "parent",
      icon: Users,
      titleKey: "roleParentTitle",
      subtitleKey: "oauthParentSubtitle",
      featureKeys: ["roleParentF1", "roleParentF2", "roleParentF3"],
      gradient: ["#0EA5E9", "#6366F1"],
    },
  ];

  const handleSelectRole = async (role) => {
    const user = auth?.currentUser;
    if (!user) {
      Alert.alert(t("error"), t("oauthSessionExpired"));
      router.replace("/role-select");
      return;
    }

    setLoading(role);
    try {
      const nameParts = (user.displayName ?? "").split(" ");
      const firstName = nameParts[0] ?? "";
      const lastName = nameParts.slice(1).join(" ") ?? "";
      const email = user.email ?? "";

      if (role === "teacher") {
        await registerTeacher(user.uid, { firstName, lastName, email });
        await AsyncStorage.setItem("userRole", "teacher");
      } else {
        await registerParent(user.uid, { firstName, lastName, email });
        await AsyncStorage.setItem("userRole", "parent");
      }

      registerPushToken(user.uid, role).catch(() => {});
      router.replace(`/complete-profile?role=${role}`);
    } catch (e) {
      Alert.alert(t("error"), t("oauthProfileError"));
    } finally {
      setLoading(null);
    }
  };

  const user = auth?.currentUser;
  const displayName = user?.displayName || user?.email?.split("@")[0] || t("defaultUser");

  return (
    <View style={{ flex: 1, backgroundColor: "#F2F2F7" }}>
      <StatusBar barStyle="dark-content" />

      {/* Hero */}
      <LinearGradient
        colors={["#4F46E5", "#6B5CF6", "#8B5CF6"]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{
          paddingTop: insets.top + 32,
          paddingHorizontal: 28,
          paddingBottom: 48,
          alignItems: "center",
        }}
      >
        <View style={{
          width: 72, height: 72, borderRadius: 22,
          backgroundColor: "rgba(255,255,255,0.2)",
          alignItems: "center", justifyContent: "center",
          marginBottom: 20, borderWidth: 1.5,
          borderColor: "rgba(255,255,255,0.35)",
        }}>
          <Sparkles size={34} color="#FFFFFF" />
        </View>

        <Text style={{ fontSize: 26, fontFamily: "Inter_700Bold", color: "#FFFFFF", textAlign: "center", marginBottom: 8 }}>
          {t("oauthWelcome")}
        </Text>
        <Text style={{ fontSize: 16, fontFamily: "Inter_600SemiBold", color: "rgba(255,255,255,0.9)", marginBottom: 8 }}>
          {displayName}
        </Text>
        <Text style={{
          fontSize: 14, fontFamily: "Inter_400Regular",
          color: "rgba(255,255,255,0.7)",
          textAlign: "center", lineHeight: 20,
        }}>
          {t("oauthLastStep")}
        </Text>
      </LinearGradient>

      {/* Role cards */}
      <View style={{
        flex: 1, paddingHorizontal: 20,
        paddingTop: 24, paddingBottom: insets.bottom + 24,
        gap: 14,
      }}>
        {ROLES.map(role => {
          const Icon = role.icon;
          const isLoading = loading === role.key;
          return (
            <TouchableOpacity
              key={role.key}
              onPress={() => handleSelectRole(role.key)}
              disabled={loading !== null}
              activeOpacity={0.88}
            >
              <LinearGradient
                colors={role.gradient}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={{
                  borderRadius: 22, padding: 22,
                  shadowColor: role.gradient[1],
                  shadowOpacity: 0.3, shadowRadius: 14,
                  shadowOffset: { width: 0, height: 6 },
                  elevation: 6,
                  opacity: loading && !isLoading ? 0.5 : 1,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 14 }}>
                  <View style={{
                    width: 52, height: 52, borderRadius: 15,
                    backgroundColor: "rgba(255,255,255,0.22)",
                    alignItems: "center", justifyContent: "center",
                    borderWidth: 1, borderColor: "rgba(255,255,255,0.3)",
                  }}>
                    {isLoading
                      ? <ActivityIndicator color="#FFFFFF" />
                      : <Icon size={26} color="#FFFFFF" />
                    }
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: "#FFFFFF", marginBottom: 4 }}>
                      {t(role.titleKey)}
                    </Text>
                    <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.75)", marginBottom: 14, lineHeight: 18 }}>
                      {t(role.subtitleKey)}
                    </Text>
                    {role.featureKeys.map(fk => (
                      <View key={fk} style={{ flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 4 }}>
                        <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: "rgba(255,255,255,0.5)" }} />
                        <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.8)" }}>{t(fk)}</Text>
                      </View>
                    ))}
                  </View>
                  <View style={{
                    width: 36, height: 36, borderRadius: 12,
                    backgroundColor: "rgba(255,255,255,0.18)",
                    alignItems: "center", justifyContent: "center",
                    alignSelf: "center",
                  }}>
                    <ChevronRight size={18} color="#FFFFFF" />
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          );
        })}

        <Text style={{
          textAlign: "center", fontSize: 12,
          fontFamily: "Inter_400Regular", color: "#C7C7CC",
          marginTop: 8,
        }}>
          {t("roleSelectHint")}
        </Text>
      </View>
    </View>
  );
}
