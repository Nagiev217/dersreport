import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState, useMemo } from "react";
import { useRouter } from "expo-router";
import {
  Plus,
  FileText,
  Star,
  Calendar,
  BookOpen,
  ChevronRight,
} from "lucide-react-native";
import SearchBar from "@/components/SearchBar";
import FilterChips from "@/components/FilterChips";
import { useReportsStore } from "@/utils/reports/store";
import { useStudentsStore } from "@/utils/students/store";
import { formatDateFull } from "@/utils/dateUtils";
import { useT, useDateLocale } from "@/utils/i18n";

// ─── ReportCard ───────────────────────────────────────────────────────────────

const ReportCard = ({ report, onPress }) => {
  const { t } = useT();
  const locale = useDateLocale();
  const SCORE_CFG = {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2" },
  };
  const scoreCfg = SCORE_CFG[report.activityScore] ?? SCORE_CFG[3];

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 16,
        shadowColor: "#000",
        shadowOpacity: 0.06,
        shadowRadius: 8,
        shadowOffset: { width: 0, height: 2 },
        elevation: 2,
      }}
    >
      {/* Row 1: student + score badge */}
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <View
            style={{
              width: 34,
              height: 34,
              borderRadius: 10,
              backgroundColor: "#EEF0FF",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <FileText size={16} color="#6B5CF6" />
          </View>
          <View>
            <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
              {report.studentName}
            </Text>
            <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
              {report.subject}
            </Text>
          </View>
        </View>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 3,
            paddingHorizontal: 9,
            paddingVertical: 4,
            backgroundColor: scoreCfg.bg,
            borderRadius: 20,
          }}
        >
          <Star size={10} color={scoreCfg.color} fill={scoreCfg.color} />
          <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: scoreCfg.color }}>
            {scoreCfg.label}
          </Text>
        </View>
      </View>

      {/* Topic */}
      <Text
        style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#1C1C1E", marginBottom: 4 }}
        numberOfLines={1}
      >
        {report.topic}
      </Text>
      <Text
        style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#6B7280", lineHeight: 18 }}
        numberOfLines={2}
      >
        {report.description}
      </Text>

      {/* Date row */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          marginTop: 10,
          paddingTop: 10,
          borderTopWidth: 0.5,
          borderTopColor: "#F2F2F7",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Calendar size={12} color="#8E8E93" />
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
            {formatDateFull(report.date, locale)}
          </Text>
        </View>
        <ChevronRight size={14} color="#C7C7CC" />
      </View>
    </TouchableOpacity>
  );
};

// ─── Empty State ──────────────────────────────────────────────────────────────

const EmptyReports = ({ onAdd }) => {
  const { t } = useT();
  return (
  <View style={{ alignItems: "center", paddingTop: 48, paddingHorizontal: 32 }}>
    <View style={{ width: 72, height: 72, borderRadius: 22, backgroundColor: "#EEF0FF", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
      <FileText size={32} color="#6B5CF6" />
    </View>
    <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginBottom: 6, textAlign: "center" }}>
      {t("reportsEmptyTitle")}
    </Text>
    <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20, marginBottom: 24 }}>
      {t("reportsEmptyHint")}
    </Text>
    <TouchableOpacity activeOpacity={0.85} onPress={onAdd} style={{ paddingHorizontal: 24, paddingVertical: 12, backgroundColor: "#6B5CF6", borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 8 }}>
      <Plus size={16} color="#FFFFFF" />
      <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("reportsCreateBtn")}</Text>
    </TouchableOpacity>
  </View>
  );
};

// ─── Main ─────────────────────────────────────────────────────────────────────

export default function ReportsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useT();
  const [search, setSearch] = useState("");
  const [studentFilter, setStudentFilter] = useState(null);

  const { reports } = useReportsStore();
  const { students } = useStudentsStore();

  const filterAll = t("all");

  // Build filter chips from actual students with reports
  const reportStudentNames = useMemo(() => {
    const names = [...new Set(reports.map((r) => r.studentName))];
    return [filterAll, ...names];
  }, [reports, filterAll]);

  const activeStudentFilter = studentFilter ?? filterAll;

  const filtered = useMemo(() => {
    let list = reports;
    if (activeStudentFilter !== filterAll) {
      list = list.filter((r) => r.studentName === activeStudentFilter);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (r) =>
          r.topic.toLowerCase().includes(q) ||
          r.studentName.toLowerCase().includes(q) ||
          r.subject.toLowerCase().includes(q)
      );
    }
    return list;
  }, [reports, studentFilter, search]);

  // Stats
  const totalReports = reports.length;
  const excellentCount = reports.filter((r) => r.activityScore === 5).length;

  const handleAdd = () => router.push("/report/add");
  const handleOpen = (id) => router.push(`/report/${id}`);

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#F2F2F7" }}
      contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={{ paddingTop: insets.top + 12, paddingHorizontal: 20, marginBottom: 4 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
          <View>
            <Text style={{ fontSize: 32, fontFamily: "Inter_700Bold", color: "#1C1C1E", letterSpacing: -0.5 }}>
              {t("reportsTitle")}
            </Text>
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 2 }}>
              {t("reportsSubtitle")}
            </Text>
          </View>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleAdd}
            style={{
              width: 40,
              height: 40,
              borderRadius: 12,
              backgroundColor: "#6B5CF6",
              alignItems: "center",
              justifyContent: "center",
              marginTop: 4,
            }}
          >
            <Plus size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Stats row */}
      <View style={{ flexDirection: "row", paddingHorizontal: 20, marginTop: 16, gap: 10, marginBottom: 16 }}>
        {[
          { label: t("reportsTotalStat"), value: totalReports, color: "#6B5CF6", bg: "#EEF0FF" },
          { label: t("reportsExcellent"), value: excellentCount, color: "#22C55E", bg: "#F0FDF4" },
          { label: t("reportsStudents"), value: new Set(reports.map((r) => r.studentId)).size, color: "#3B82F6", bg: "#EFF6FF" },
        ].map((stat) => (
          <View
            key={stat.label}
            style={{
              flex: 1,
              backgroundColor: "#FFFFFF",
              borderRadius: 14,
              padding: 12,
              alignItems: "center",
              shadowColor: "#000",
              shadowOpacity: 0.04,
              shadowRadius: 6,
              shadowOffset: { width: 0, height: 2 },
              elevation: 1,
            }}
          >
            <Text style={{ fontSize: 24, fontFamily: "Inter_700Bold", color: stat.color }}>
              {stat.value}
            </Text>
            <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", marginTop: 2 }}>
              {stat.label}
            </Text>
          </View>
        ))}
      </View>

      {/* Search */}
      <View style={{ paddingHorizontal: 20, marginBottom: 12 }}>
        <SearchBar
          placeholder={t("reportsSearch")}
          value={search}
          onChangeText={setSearch}
          showMic={false}
        />
      </View>

      {/* Filters */}
      {reportStudentNames.length > 1 && (
        <View style={{ paddingLeft: 20, marginBottom: 16 }}>
          <FilterChips
            options={reportStudentNames}
            selected={activeStudentFilter}
            onSelect={setStudentFilter}
          />
        </View>
      )}

      {/* List */}
      <View style={{ paddingHorizontal: 20, gap: 10 }}>
        {filtered.length === 0 ? (
          <EmptyReports onAdd={handleAdd} />
        ) : (
          filtered.map((report) => (
            <ReportCard
              key={report.id}
              report={report}
              onPress={() => handleOpen(report.id)}
            />
          ))
        )}
      </View>
    </ScrollView>
  );
}
