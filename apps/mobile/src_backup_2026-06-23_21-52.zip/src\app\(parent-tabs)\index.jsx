import { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import {
  BookOpen,
  Calendar,
  FileText,
  BarChart2,
  Star,
  Clock,
  Shield,
  LogOut,
  CheckCircle2,
} from "lucide-react-native";
import { signOut } from "firebase/auth";
import { auth } from "../../utils/firebase/config";
import {
  getParentProfile,
  getParentAccess,
  loadTeacherStore,
} from "../../utils/firebase/roles";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useT } from "../../utils/i18n";

const pad = (n) => String(n).padStart(2, "0");
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function formatDate(s, monthsArr) {
  if (!s) return "";
  const [, m, d] = s.split("-").map(Number);
  return `${d} ${monthsArr[m - 1]}`;
}

// SCORE_LABELS built inside components using useT()

function StatCard({ icon: Icon, label, value, color, bg }) {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: bg ?? "#EEF0FF",
        borderRadius: 14,
        padding: 12,
        alignItems: "center",
        gap: 4,
      }}
    >
      <Icon size={18} color={color ?? "#0EA5E9"} />
      <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: color ?? "#0EA5E9" }}>
        {value}
      </Text>
      <Text style={{ fontSize: 10, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center" }}>
        {label}
      </Text>
    </View>
  );
}

function ChildCard({ student, reports, lessons, onPress, monthsShort }) {
  const { t } = useT();
  const SCORE_LABELS = {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2" },
  };
  const today = todayStr();
  const upcomingLesson = lessons
    .filter(
      (l) =>
        (l.studentIds ?? []).includes(String(student.id)) &&
        l.date >= today &&
        l.status === "planned"
    )
    .sort((a, b) => `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`))[0];

  const myReports = reports
    .filter((r) => String(r.studentId) === String(student.id))
    .sort((a, b) => b.createdAt - a.createdAt);
  const lastReport = myReports[0];
  const scoreCfg = lastReport ? SCORE_LABELS[lastReport.activityScore] : null;

  return (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={onPress}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 20,
        marginHorizontal: 20,
        marginBottom: 12,
        padding: 18,
        shadowColor: "#000",
        shadowOpacity: 0.07,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 4 },
        elevation: 3,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
        <View
          style={{
            width: 48,
            height: 48,
            borderRadius: 24,
            backgroundColor: student.avatarColor ?? "#0EA5E9",
            alignItems: "center",
            justifyContent: "center",
            marginRight: 12,
          }}
        >
          <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>
            {student.name?.[0] ?? "?"}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
            {student.name}
          </Text>
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
            {student.subject} · {student.type}
          </Text>
        </View>
        {scoreCfg && (
          <View style={{ paddingHorizontal: 10, paddingVertical: 4, backgroundColor: scoreCfg.bg, borderRadius: 20 }}>
            <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: scoreCfg.color }}>
              {scoreCfg.label}
            </Text>
          </View>
        )}
      </View>

      <View
        style={{
          flexDirection: "row",
          gap: 8,
          paddingTop: 12,
          borderTopWidth: 0.5,
          borderTopColor: "#F2F2F7",
          marginBottom: upcomingLesson ? 10 : 0,
        }}
      >
        <StatCard icon={BookOpen} label={t("parentStatLessons")} value={student.lessonsCompleted ?? 0} color="#0EA5E9" bg="#E0F2FE" />
        <StatCard icon={BarChart2} label={t("parentStatAttend")} value={`${student.attendance ?? 0}%`} color="#22C55E" bg="#F0FDF4" />
        <StatCard icon={FileText} label={t("parentStatReports")} value={myReports.length} color="#6B5CF6" bg="#EEF0FF" />
      </View>

      {upcomingLesson && (
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            backgroundColor: "#E0F2FE",
            borderRadius: 10,
            paddingHorizontal: 10,
            paddingVertical: 7,
          }}
        >
          <Calendar size={13} color="#0EA5E9" />
          <Text style={{ fontSize: 12, fontFamily: "Inter_500Medium", color: "#0EA5E9" }}>
            {t("parentNextLesson")}: {formatDate(upcomingLesson.date, monthsShort)}, {upcomingLesson.time}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

export default function ParentDashboard() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t, months } = useT();
  const monthsShort = months(true);

  const SCORE_LABELS = {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2" },
  };

  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [children, setChildren] = useState([]);
  const [allLessons, setAllLessons] = useState([]);
  const [allReports, setAllReports] = useState([]);

  const uid = auth?.currentUser?.uid;
  const displayName = auth?.currentUser?.displayName ?? t("roleParentTitle");

  useEffect(() => {
    if (!uid) { setLoading(false); return; }
    loadData();
  }, [uid]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [prof, links] = await Promise.all([
        getParentProfile(uid),
        getParentAccess(uid),
      ]);
      setProfile(prof);

      if (!links.length) { setLoading(false); return; }

      const allStudents = [];
      const allLess = [];
      const allRep = [];

      await Promise.all(
        links.map(async ({ teacherUid, studentIds }) => {
          const [studs, lessons, reports] = await Promise.all([
            loadTeacherStore(teacherUid, "students"),
            loadTeacherStore(teacherUid, "lessons"),
            loadTeacherStore(teacherUid, "reports"),
          ]);

          if (studs) {
            const allowed = new Set(studentIds.map(String));
            allStudents.push(...studs.filter((s) => allowed.has(String(s.id))));
          }
          if (lessons) {
            const allowed = new Set(studentIds.map(String));
            allLess.push(
              ...lessons.filter((l) =>
                (l.studentIds ?? []).some((sid) => allowed.has(String(sid)))
              )
            );
          }
          if (reports) {
            const allowed = new Set(studentIds.map(String));
            allRep.push(
              ...reports.filter((r) => allowed.has(String(r.studentId)))
            );
          }
        })
      );

      setChildren(allStudents);
      setAllLessons(allLess);
      setAllReports(allRep.sort((a, b) => b.createdAt - a.createdAt));
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = () => {
    Alert.alert(
      t("profileSignOutTitle"),
      t("profileSignOutMsg"),
      [
        { text: t("cancel"), style: "cancel" },
        {
          text: t("profileSignOutBtn"),
          style: "destructive",
          onPress: async () => {
            await AsyncStorage.removeItem("userRole");
            signOut(auth)
              .then(() => router.replace("/role-select"))
              .catch(() => router.replace("/role-select"));
          },
        },
      ]
    );
  };

  const today = todayStr();
  const upcomingLessons = allLessons
    .filter(
      (l) =>
        l.date >= today &&
        l.status === "planned" &&
        children.some((c) => (l.studentIds ?? []).includes(String(c.id)))
    )
    .sort((a, b) => `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`))
    .slice(0, 4);

  const recentReports = allReports.slice(0, 3);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: "#F2F2F7", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color="#0EA5E9" size="large" />
        <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 12 }}>
          {t("loadingData")}
        </Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#F2F2F7" }}
      contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: "#0EA5E9",
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 28,
          borderBottomLeftRadius: 28,
          borderBottomRightRadius: 28,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(255,255,255,0.2)", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 }}>
            <Shield size={12} color="#FFFFFF" />
            <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("parentDashboardBadge")}</Text>
          </View>
          <TouchableOpacity
            onPress={handleSignOut}
            style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}
          >
            <LogOut size={16} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <View
            style={{
              width: 52,
              height: 52,
              borderRadius: 26,
              backgroundColor: "rgba(255,255,255,0.25)",
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 2,
              borderColor: "rgba(255,255,255,0.4)",
            }}
          >
            <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>
              {displayName[0]}
            </Text>
          </View>
          <View>
            <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)" }}>
              {t("parentWelcome")}
            </Text>
            <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>
              {displayName}
            </Text>
          </View>
        </View>

        {/* Summary stats */}
        <View style={{ flexDirection: "row", gap: 10, marginTop: 20 }}>
          {[
            { icon: BookOpen, label: t("parentStatChildren"), value: children.length, bg: "rgba(255,255,255,0.15)" },
            { icon: Clock, label: t("parentStatUpcoming"), value: upcomingLessons.length, bg: "rgba(255,255,255,0.15)" },
            { icon: FileText, label: t("parentStatReports"), value: allReports.length, bg: "rgba(255,255,255,0.15)" },
          ].map(({ icon: Icon, label, value, bg }) => (
            <View key={label} style={{ flex: 1, backgroundColor: bg, borderRadius: 12, padding: 10, alignItems: "center" }}>
              <Icon size={16} color="rgba(255,255,255,0.8)" />
              <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#FFFFFF", marginTop: 4 }}>{value}</Text>
              <Text style={{ fontSize: 10, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)" }}>{label}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Empty state */}
      {children.length === 0 && (
        <View style={{ margin: 20, backgroundColor: "#FFFFFF", borderRadius: 20, padding: 32, alignItems: "center" }}>
          <Shield size={40} color="#C7C7CC" />
          <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginTop: 16, marginBottom: 8 }}>
            {t("parentNoChildren")}
          </Text>
          <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20 }}>
            {t("parentNoChildrenHint")}
          </Text>
          <TouchableOpacity
            onPress={() => router.push("/(parent-tabs)/profile")}
            style={{ marginTop: 16, paddingHorizontal: 24, paddingVertical: 12, backgroundColor: "#0EA5E9", borderRadius: 14 }}
          >
            <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("parentMyID")}</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Children */}
      {children.length > 0 && (
        <>
          <View style={{ paddingHorizontal: 20, marginTop: 20, marginBottom: 10 }}>
            <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
              {children.length === 1 ? t("parentMyChild") : t("parentMyChildren")}
            </Text>
          </View>
          {children.map((student) => (
            <ChildCard
              key={student.id}
              student={student}
              reports={allReports}
              lessons={allLessons}
              monthsShort={monthsShort}
              onPress={() => router.push(`/(parent-tabs)/reports?highlight=${student.id}`)}
            />
          ))}
        </>
      )}

      {/* Upcoming lessons */}
      {upcomingLessons.length > 0 && (
        <View style={{ marginHorizontal: 20, marginTop: 8, marginBottom: 16 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>{t("parentUpcomingLessons")}</Text>
            <Clock size={15} color="#8E8E93" />
          </View>
          <View style={{ backgroundColor: "#FFFFFF", borderRadius: 16, paddingHorizontal: 16, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2 }}>
            {upcomingLessons.map((lesson, i) => {
              const childName = children.find((c) =>
                (lesson.studentIds ?? []).includes(String(c.id))
              )?.name ?? "—";
              return (
                <View
                  key={lesson.id}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingVertical: 12,
                    borderBottomWidth: i < upcomingLessons.length - 1 ? 0.5 : 0,
                    borderBottomColor: "#F2F2F7",
                    gap: 12,
                  }}
                >
                  <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#E0F2FE", alignItems: "center", justifyContent: "center" }}>
                    <BookOpen size={15} color="#0EA5E9" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#1C1C1E" }}>
                      {lesson.subject} · {childName}
                    </Text>
                    <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
                      {formatDate(lesson.date, monthsShort)}, {lesson.time} · {lesson.duration} {t("min_abbr")}
                    </Text>
                  </View>
                </View>
              );
            })}
            <View style={{ height: 4 }} />
          </View>
        </View>
      )}

      {/* Recent reports */}
      {recentReports.length > 0 && (
        <View style={{ marginHorizontal: 20, marginBottom: 16 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>{t("parentRecentReports")}</Text>
            <TouchableOpacity onPress={() => router.push("/(parent-tabs)/reports")}>
              <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "#0EA5E9" }}>{t("all")}</Text>
            </TouchableOpacity>
          </View>
          <View style={{ gap: 8 }}>
            {recentReports.map((report) => {
              const cfg = SCORE_LABELS[report.activityScore] ?? SCORE_LABELS[3];
              return (
                <View
                  key={report.id}
                  style={{
                    backgroundColor: "#FFFFFF",
                    borderRadius: 14,
                    padding: 14,
                    borderLeftWidth: 3,
                    borderLeftColor: cfg.color,
                    shadowColor: "#000",
                    shadowOpacity: 0.04,
                    shadowRadius: 6,
                    elevation: 2,
                  }}
                >
                  <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                    <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
                      {report.studentName}
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                      <Star size={10} color={cfg.color} fill={cfg.color} />
                      <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: cfg.color }}>{cfg.label}</Text>
                    </View>
                  </View>
                  <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "#3C3C43" }} numberOfLines={1}>{report.topic}</Text>
                  <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 3 }}>
                    {formatDate(report.date, monthsShort)} · {report.subject}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      )}
    </ScrollView>
  );
}
