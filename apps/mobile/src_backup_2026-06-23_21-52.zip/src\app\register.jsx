import React, { useState, useRef, useEffect } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, StatusBar,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import {
  User, Mail, Lock, Eye, EyeOff,
  GraduationCap, Users, ArrowLeft, ArrowRight,
} from "lucide-react-native";
import * as WebBrowser from "expo-web-browser";
import * as Google from "expo-auth-session/providers/google";
import * as AppleAuthentication from "expo-apple-authentication";
import * as Crypto from "expo-crypto";
import { IS_FIREBASE_READY } from "@/utils/firebase/config";
import {
  signInWithGoogleToken,
  signInWithAppleToken,
  resolveOAuthUser,
  getOAuthError,
  GOOGLE_CONFIG,
  OAUTH_CONFIGURED,
} from "@/utils/firebase/oauth";
import { registerPushToken } from "@/utils/firebase/notifications";
import { sendVerificationCode } from "@/utils/firebase/verification";
import { useRegistrationStore } from "@/utils/auth/registrationStore";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useT } from "@/utils/i18n";

WebBrowser.maybeCompleteAuthSession();

const ROLE_GRADIENT = {
  teacher: ["#4F46E5", "#6B5CF6"],
  parent:  ["#0EA5E9", "#6366F1"],
};
const ROLE_ICON = { teacher: GraduationCap, parent: Users };
const ROLE_COLOR = { teacher: "#6B5CF6", parent: "#0EA5E9" };

function GoogleIcon({ size = 20 }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: size * 0.68, fontFamily: "Inter_700Bold", color: "#4285F4", lineHeight: size * 0.85 }}>G</Text>
    </View>
  );
}

function OAuthButton({ onPress, loading, disabled, children, style }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
      style={[{
        height: 52, borderRadius: 14,
        flexDirection: "row", alignItems: "center", justifyContent: "center",
        gap: 10, opacity: disabled ? 0.6 : 1,
      }, style]}
    >
      {loading ? <ActivityIndicator color="#1C1C1E" size="small" /> : children}
    </TouchableOpacity>
  );
}

function OrDivider({ text }) {
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginVertical: 16 }}>
      <View style={{ flex: 1, height: 1, backgroundColor: "rgba(255,255,255,0.2)" }} />
      <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "rgba(255,255,255,0.55)" }}>
        {text}
      </Text>
      <View style={{ flex: 1, height: 1, backgroundColor: "rgba(255,255,255,0.2)" }} />
    </View>
  );
}

function StrengthBar({ password, labels }) {
  const score = password.length === 0 ? 0
    : password.length < 6 ? 1
    : password.length < 10 ? 2
    : /[A-Z]/.test(password) && /[0-9]/.test(password) ? 4 : 3;
  const colors = ["transparent", "#EF4444", "#F59E0B", "#22C55E", "#6B5CF6"];
  if (password.length === 0) return null;
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 4 }}>
      {[1, 2, 3, 4].map(i => (
        <View key={i} style={{ flex: 1, height: 3, borderRadius: 2, backgroundColor: i <= score ? colors[score] : "rgba(255,255,255,0.2)" }} />
      ))}
      <Text style={{ fontSize: 11, fontFamily: "Inter_500Medium", color: colors[score], marginLeft: 4 }}>
        {labels[score]}
      </Text>
    </View>
  );
}

function Field({ icon: Icon, placeholder, value, onChangeText, secure, right, keyboardType, fRef, onSubmitEditing, returnKeyType }) {
  return (
    <View style={{
      flexDirection: "row", alignItems: "center",
      backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 14,
      paddingHorizontal: 16, height: 54, gap: 12,
      borderWidth: 1, borderColor: "rgba(255,255,255,0.25)",
    }}>
      <Icon size={18} color="rgba(255,255,255,0.7)" />
      <TextInput
        ref={fRef}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="rgba(255,255,255,0.5)"
        secureTextEntry={secure}
        keyboardType={keyboardType ?? "default"}
        autoCapitalize={keyboardType === "email-address" ? "none" : "words"}
        autoCorrect={false}
        returnKeyType={returnKeyType ?? "next"}
        onSubmitEditing={onSubmitEditing}
        style={{ flex: 1, fontSize: 15, fontFamily: "Inter_400Regular", color: "#FFFFFF" }}
      />
      {right}
    </View>
  );
}

export default function RegisterScreen() {
  const insets = useSafeAreaInsets();
  const { role } = useLocalSearchParams();
  const effectiveRole = role === "parent" ? "parent" : "teacher";
  const { t } = useT();

  const gradient = ROLE_GRADIENT[effectiveRole];
  const RoleIcon = ROLE_ICON[effectiveRole];
  const roleColor = ROLE_COLOR[effectiveRole];
  const subtitle = effectiveRole === "parent" ? t("registerParentSubtitle") : t("registerTeacherSubtitle");

  const strengthLabels = ["", t("pwdStrengthWeak"), t("pwdStrengthMedium"), t("pwdStrengthGood"), t("pwdStrengthExcellent")];

  // Email state
  const [firstName, setFirstName]   = useState("");
  const [lastName, setLastName]     = useState("");
  const [email, setEmail]           = useState("");
  const [password, setPassword]     = useState("");
  const [confirm, setConfirm]       = useState("");
  const [showPw, setShowPw]         = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [emailLoading, setEmailLoading] = useState(false);
  const [error, setError]           = useState("");

  // OAuth state
  const [googleLoading, setGoogleLoading] = useState(false);
  const [appleLoading, setAppleLoading]   = useState(false);
  const [appleAvailable, setAppleAvailable] = useState(false);

  const anyLoading = emailLoading || googleLoading || appleLoading;

  const setPending = useRegistrationStore((s) => s.setPending);

  // Refs for keyboard navigation
  const lastRef  = useRef();
  const emailRef = useRef();
  const pwRef    = useRef();
  const cfRef    = useRef();

  // ── Apple availability ─────────────────────────────────────────────────────
  useEffect(() => {
    AppleAuthentication.isAvailableAsync().then(setAppleAvailable).catch(() => {});
  }, []);

  // ── Google setup ────────────────────────────────────────────────────────────
  const [, googleResponse, promptGoogleAsync] = Google.useAuthRequest({
    webClientId:     GOOGLE_CONFIG.webClientId,
    iosClientId:     GOOGLE_CONFIG.iosClientId,
    androidClientId: GOOGLE_CONFIG.androidClientId,
    selectAccount: true,
  });

  useEffect(() => {
    if (googleResponse?.type === "success") {
      const idToken = googleResponse.params?.id_token;
      if (idToken) handleGoogleToken(idToken);
    } else if (googleResponse?.type === "error") {
      const msg = getOAuthError(googleResponse.error);
      if (msg) setError(msg);
      setGoogleLoading(false);
    } else if (googleResponse?.type === "dismiss" || googleResponse?.type === "cancel") {
      setGoogleLoading(false);
    }
  }, [googleResponse]);

  // ── OAuth helpers ────────────────────────────────────────────────────────────
  async function routeOAuthUser(uid) {
    const result = await resolveOAuthUser(uid);
    if (result.needsRole) {
      router.replace("/oauth-role-select");
    } else {
      await AsyncStorage.setItem("userRole", result.role);
      router.replace(result.role === "parent" ? "/(parent-tabs)" : "/(tabs)");
    }
  }

  async function handleGoogleToken(idToken) {
    setGoogleLoading(true);
    setError("");
    try {
      const { user } = await signInWithGoogleToken(idToken);
      registerPushToken(user.uid, "unknown").catch(() => {});
      await routeOAuthUser(user.uid);
    } catch (e) {
      const msg = getOAuthError(e);
      if (msg) setError(msg);
    } finally {
      setGoogleLoading(false);
    }
  }

  const handleGooglePress = async () => {
    if (!OAUTH_CONFIGURED) {
      setError("Google Sign-In not configured. Add Client IDs in oauth.js");
      return;
    }
    setError("");
    setGoogleLoading(true);
    try {
      await promptGoogleAsync();
    } catch (e) {
      setGoogleLoading(false);
      const msg = getOAuthError(e);
      if (msg) setError(msg);
    }
  };

  const handleApplePress = async () => {
    setError("");
    setAppleLoading(true);
    try {
      const nonce = Math.random().toString(36).substring(2, 18);
      const hashedNonce = await Crypto.digestStringAsync(
        Crypto.CryptoDigestAlgorithm.SHA256, nonce
      );
      const appleResult = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
        nonce: hashedNonce,
      });
      const { user } = await signInWithAppleToken(appleResult.identityToken, nonce);
      registerPushToken(user.uid, "unknown").catch(() => {});
      await routeOAuthUser(user.uid);
    } catch (e) {
      const msg = getOAuthError(e);
      if (msg) setError(msg);
    } finally {
      setAppleLoading(false);
    }
  };

  // ── Email registration (OTP flow) ────────────────────────────────────────
  const canSubmit =
    firstName.trim().length >= 2 &&
    lastName.trim().length >= 2 &&
    email.trim().length > 3 &&
    password.length >= 6 &&
    confirm === password &&
    !anyLoading;

  const handleEmailRegister = async () => {
    if (!canSubmit) return;
    if (password !== confirm) { setError(t("pwdMismatch")); return; }
    if (!IS_FIREBASE_READY) { setError(t("errorGeneric")); return; }
    setError("");
    setEmailLoading(true);
    try {
      await sendVerificationCode({
        email: email.trim().toLowerCase(),
        firstName: firstName.trim(),
      });
      setPending({
        email: email.trim().toLowerCase(),
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        password,
        role: effectiveRole,
      });
      router.push("/verify-email");
    } catch (e) {
      setError(e.message ?? t("errorGeneric"));
    } finally {
      setEmailLoading(false);
    }
  };

  return (
    <LinearGradient colors={gradient} start={{ x: 0, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ flex: 1 }}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <ScrollView
          contentContainerStyle={{
            flexGrow: 1,
            paddingHorizontal: 28,
            paddingTop: insets.top + 16,
            paddingBottom: insets.bottom + 32,
          }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Back */}
          <TouchableOpacity
            onPress={() => router.back()}
            style={{ alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 24, opacity: 0.8 }}
          >
            <ArrowLeft size={16} color="#FFFFFF" />
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#FFFFFF" }}>{t("back")}</Text>
          </TouchableOpacity>

          {/* Header */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 28 }}>
            <View style={{
              width: 52, height: 52, borderRadius: 15,
              backgroundColor: "rgba(255,255,255,0.2)",
              alignItems: "center", justifyContent: "center",
              borderWidth: 1.5, borderColor: "rgba(255,255,255,0.35)",
            }}>
              <RoleIcon size={24} color="#FFFFFF" />
            </View>
            <View>
              <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#FFFFFF", letterSpacing: -0.3 }}>
                {t("registerTitle")}
              </Text>
              <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)" }}>
                {subtitle}
              </Text>
            </View>
          </View>

          {/* ── OAuth buttons ─────────────────────────────────────────────── */}
          <View style={{ gap: 10 }}>
            <OAuthButton
              onPress={handleGooglePress}
              loading={googleLoading}
              disabled={anyLoading}
              style={{ backgroundColor: "#FFFFFF" }}
            >
              <GoogleIcon size={20} />
              <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#1C1C1E" }}>
                {t("continueWithGoogle")}
              </Text>
            </OAuthButton>

            {appleAvailable && (
              <OAuthButton
                onPress={handleApplePress}
                loading={appleLoading}
                disabled={anyLoading}
                style={{ backgroundColor: "#000000" }}
              >
                <Text style={{ fontSize: 18, color: "#FFFFFF", lineHeight: 22 }}>⌘</Text>
                <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>
                  {t("continueWithApple")}
                </Text>
              </OAuthButton>
            )}
          </View>

          <OrDivider text={t("orViaEmail")} />

          {/* ── Email registration form ───────────────────────────────────── */}
          {/* Name row */}
          <View style={{ flexDirection: "row", gap: 10, marginBottom: 10 }}>
            <View style={{ flex: 1 }}>
              <Field
                icon={User} placeholder={t("firstNameField")} value={firstName}
                onChangeText={setFirstName}
                returnKeyType="next"
                onSubmitEditing={() => lastRef.current?.focus()}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Field
                icon={User} placeholder={t("lastNameField")} value={lastName}
                onChangeText={setLastName} fRef={lastRef}
                returnKeyType="next"
                onSubmitEditing={() => emailRef.current?.focus()}
              />
            </View>
          </View>

          <View style={{ gap: 10, marginBottom: 8 }}>
            <Field
              icon={Mail} placeholder="Email" value={email}
              onChangeText={setEmail} keyboardType="email-address"
              fRef={emailRef} returnKeyType="next"
              onSubmitEditing={() => pwRef.current?.focus()}
            />
            <View style={{ gap: 6 }}>
              <Field
                icon={Lock} placeholder={t("passwordMinField")} value={password}
                onChangeText={setPassword} secure={!showPw}
                fRef={pwRef} returnKeyType="next"
                onSubmitEditing={() => cfRef.current?.focus()}
                right={
                  <TouchableOpacity onPress={() => setShowPw(v => !v)}>
                    {showPw ? <EyeOff size={18} color="rgba(255,255,255,0.7)" /> : <Eye size={18} color="rgba(255,255,255,0.7)" />}
                  </TouchableOpacity>
                }
              />
              <StrengthBar password={password} labels={strengthLabels} />
            </View>
            <Field
              icon={Lock} placeholder={t("confirmPwdField")} value={confirm}
              onChangeText={setConfirm} secure={!showConfirm}
              fRef={cfRef} returnKeyType="done"
              onSubmitEditing={handleEmailRegister}
              right={
                <TouchableOpacity onPress={() => setShowConfirm(v => !v)}>
                  {showConfirm ? <EyeOff size={18} color="rgba(255,255,255,0.7)" /> : <Eye size={18} color="rgba(255,255,255,0.7)" />}
                </TouchableOpacity>
              }
            />
            {confirm.length > 0 && confirm !== password && (
              <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#FCA5A5", paddingHorizontal: 4 }}>
                {t("pwdMismatch")}
              </Text>
            )}
          </View>

          {/* Error */}
          {!!error && (
            <View style={{
              backgroundColor: "rgba(239,68,68,0.2)", borderRadius: 12,
              paddingHorizontal: 14, paddingVertical: 10, marginBottom: 12,
              borderWidth: 1, borderColor: "rgba(239,68,68,0.4)",
            }}>
              <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#FCA5A5", textAlign: "center" }}>
                {error}
              </Text>
            </View>
          )}

          {/* Submit */}
          <TouchableOpacity
            onPress={handleEmailRegister}
            disabled={!canSubmit}
            activeOpacity={0.85}
            style={{
              height: 52, borderRadius: 14,
              backgroundColor: canSubmit ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0.28)",
              alignItems: "center", justifyContent: "center",
              flexDirection: "row", gap: 8, marginTop: 4,
            }}
          >
            {emailLoading ? (
              <ActivityIndicator color={roleColor} />
            ) : (
              <>
                <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: roleColor }}>
                  {t("registerContinueBtn")}
                </Text>
                <ArrowRight size={17} color={roleColor} />
              </>
            )}
          </TouchableOpacity>

          {effectiveRole === "parent" && (
            <Text style={{
              textAlign: "center", fontSize: 12,
              fontFamily: "Inter_400Regular",
              color: "rgba(255,255,255,0.5)",
              marginTop: 12, lineHeight: 18,
            }}>
              {t("registerParentHint")}
            </Text>
          )}

          {/* Sign-in link */}
          <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", marginTop: 18, gap: 4 }}>
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)" }}>
              {t("haveAccount")}
            </Text>
            <TouchableOpacity onPress={() => router.replace(`/login?role=${effectiveRole}`)}>
              <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>{t("loginLink")}</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}
