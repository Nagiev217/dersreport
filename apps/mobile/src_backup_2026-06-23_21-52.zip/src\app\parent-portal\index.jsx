import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  ArrowLeft,
  BookOpen,
  Star,
  Calendar,
  CheckCircle2,
  Clock,
  BarChart2,
  ChevronRight,
  FileText,
  Shield,
  TrendingUp,
} from "lucide-react-native";
import { useParentsStore } from "@/utils/parents/store";
import { useStudentsStore } from "@/utils/students/store";
import { useReportsStore } from "@/utils/reports/store";
import { useLessonsStore } from "@/utils/lessons/store";
import { formatDateShort, formatDateFull, todayStr, toDateStr } from "@/utils/dateUtils";
import { useT, useDateLocale } from "@/utils/i18n";

// ─── Config ────────────────────────────────────────────────────────────────────

function makeScoreCfg(t) {
  return {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2" },
  };
}

// ─── Child Summary Card ────────────────────────────────────────────────────────

const ChildCard = ({ student, reports, lessons, onPress }) => {
  const { t } = useT();
  const locale = useDateLocale();
  const SCORE_CFG = makeScoreCfg(t);
  const studentReports = reports.filter((r) => r.studentId === student.id);
  const latestReport = studentReports[0];
  const scoreCfg = latestReport ? SCORE_CFG[latestReport.activityScore] ?? SCORE_CFG[3] : null;

  const today = todayStr();
  const tomorrow = toDateStr((() => { const d = new Date(); d.setDate(d.getDate() + 1); return d; })());
  const upcomingLesson = lessons
    .filter((l) => (l.studentIds ?? []).includes(student.id) && l.date >= today && l.status === "planned")
    .sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`))[0];

  const scoreColor =
    student.score >= 8 ? "#22C55E" : student.score >= 7 ? "#3B82F6" : "#F59E0B";

  return (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={onPress}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 20,
        marginHorizontal: 20,
        marginBottom: 12,
        padding: 18,
        shadowColor: "#000",
        shadowOpacity: 0.07,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 4 },
        elevation: 3,
      }}
    >
      {/* Row 1: avatar + name + badge */}
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 14 }}>
        <View
          style={{
            width: 52,
            height: 52,
            borderRadius: 26,
            backgroundColor: student.avatarColor ?? "#6B5CF6",
            alignItems: "center",
            justifyContent: "center",
            marginRight: 12,
            shadowColor: student.avatarColor ?? "#6B5CF6",
            shadowOpacity: 0.35,
            shadowRadius: 8,
            elevation: 3,
          }}
        >
          <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>
            {student.name?.[0] ?? "?"}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 17, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
            {student.name}
          </Text>
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
            {student.type} · {student.subject}
          </Text>
        </View>
        {scoreCfg && (
          <View style={{ paddingHorizontal: 8, paddingVertical: 4, backgroundColor: scoreCfg.bg, borderRadius: 20 }}>
            <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: scoreCfg.color }}>
              {scoreCfg.label}
            </Text>
          </View>
        )}
      </View>

      {/* Stats row */}
      <View
        style={{
          flexDirection: "row",
          gap: 8,
          paddingTop: 14,
          borderTopWidth: 0.5,
          borderTopColor: "#F2F2F7",
          marginBottom: 12,
        }}
      >
        {[
          { label: t("parentStatScore"),   value: `${student.score ?? 0}/${student.maxScore ?? 10}`, color: scoreColor },
          { label: t("parentStatLessons"), value: student.lessonsCompleted ?? 0, color: "#6B5CF6" },
          { label: t("parentStatAttend"), value: `${student.attendance ?? 0}%`, color: student.attendance >= 90 ? "#22C55E" : "#F59E0B" },
          { label: t("parentStatReports"), value: studentReports.length, color: "#3B82F6" },
        ].map((stat) => (
          <View key={stat.label} style={{ flex: 1, alignItems: "center" }}>
            <Text style={{ fontSize: 16, fontFamily: "Inter_700Bold", color: stat.color }}>
              {stat.value}
            </Text>
            <Text style={{ fontSize: 10, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 2 }}>
              {stat.label}
            </Text>
          </View>
        ))}
      </View>

      {/* Next lesson */}
      {upcomingLesson && (
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            backgroundColor: "#EEF0FF",
            borderRadius: 10,
            paddingHorizontal: 10,
            paddingVertical: 7,
          }}
        >
          <Calendar size={13} color="#6B5CF6" />
          <Text style={{ fontSize: 12, fontFamily: "Inter_500Medium", color: "#6B5CF6", flex: 1 }}>
            {t("parentNextLesson")}: {formatDateShort(upcomingLesson.date, locale)}, {upcomingLesson.time}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

// ─── Report Preview Card ───────────────────────────────────────────────────────

const ReportPreviewCard = ({ report, onPress, isNew }) => {
  const { t } = useT();
  const locale = useDateLocale();
  const SCORE_CFG = makeScoreCfg(t);
  const scoreCfg = SCORE_CFG[report.activityScore] ?? SCORE_CFG[3];
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 14,
        padding: 14,
        marginBottom: 8,
        borderLeftWidth: 3,
        borderLeftColor: scoreCfg.color,
        shadowColor: "#000",
        shadowOpacity: 0.04,
        shadowRadius: 6,
        shadowOffset: { width: 0, height: 2 },
        elevation: 2,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
            {report.studentName}
          </Text>
          {isNew && (
            <View style={{ paddingHorizontal: 6, paddingVertical: 2, backgroundColor: "#EEF0FF", borderRadius: 8 }}>
              <Text style={{ fontSize: 9, fontFamily: "Inter_700Bold", color: "#6B5CF6", letterSpacing: 0.5 }}>NEW</Text>
            </View>
          )}
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
          <Star size={10} color={scoreCfg.color} fill={scoreCfg.color} />
          <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: scoreCfg.color }}>
            {scoreCfg.label}
          </Text>
        </View>
      </View>
      <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "#3C3C43" }} numberOfLines={1}>
        {report.topic}
      </Text>
      <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 4 }}>
        {formatDateFull(report.date, locale)} · {report.subject}
      </Text>
    </TouchableOpacity>
  );
};

// ─── Upcoming Lesson Row ───────────────────────────────────────────────────────

const UpcomingLessonRow = ({ lesson, studentName }) => {
  const { t } = useT();
  const locale = useDateLocale();
  return (
  <View
    style={{
      flexDirection: "row",
      alignItems: "center",
      paddingVertical: 10,
      borderBottomWidth: 0.5,
      borderBottomColor: "#F2F2F7",
      gap: 12,
    }}
  >
    <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#EEF0FF", alignItems: "center", justifyContent: "center" }}>
      <BookOpen size={16} color="#6B5CF6" />
    </View>
    <View style={{ flex: 1 }}>
      <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#1C1C1E" }}>
        {lesson.subject} · {studentName}
      </Text>
      <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
        {formatDateShort(lesson.date, locale)}, {lesson.time} · {lesson.duration} {t("min_abbr")} · {lesson.format}
      </Text>
    </View>
  </View>
  );
};

// ─── Main ─────────────────────────────────────────────────────────────────────

export default function ParentPortalScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { parentId } = useLocalSearchParams();
  const { t } = useT();

  const { parents } = useParentsStore();
  const { students } = useStudentsStore();
  const { reports, markAsRead } = useReportsStore();
  const { lessons } = useLessonsStore();

  const parent = parents.find((p) => p.id === parentId);

  if (!parent) {
    return (
      <View style={{ flex: 1, backgroundColor: "#F2F2F7", alignItems: "center", justifyContent: "center", padding: 32 }}>
        <Shield size={48} color="#C7C7CC" />
        <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginTop: 16, marginBottom: 8 }}>{t("portalNotFound")}</Text>
        <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20, marginBottom: 24 }}>
          {t("portalNotFoundDesc")}
        </Text>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => router.back()}
          style={{ paddingHorizontal: 24, paddingVertical: 12, backgroundColor: "#6B5CF6", borderRadius: 14 }}
        >
          <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("back")}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const myStudents = students.filter((s) =>
    (parent.studentIds ?? []).includes(s.id)
  );
  const myStudentIds = new Set(myStudents.map((s) => s.id));

  const myReports = reports
    .filter((r) => myStudentIds.has(r.studentId))
    .sort((a, b) => b.createdAt - a.createdAt);

  const unreadCount = myReports.filter((r) => !r.isRead).length;

  const today = todayStr();
  const upcomingLessons = lessons
    .filter(
      (l) =>
        l.date >= today &&
        l.status === "planned" &&
        (l.studentIds ?? []).some((id) => myStudentIds.has(id))
    )
    .sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`))
    .slice(0, 5);

  // Average score across all children
  const avgScore = myStudents.length
    ? (myStudents.reduce((acc, s) => acc + (s.score ?? 0), 0) / myStudents.length).toFixed(1)
    : "—";

  const totalLessons = myStudents.reduce((acc, s) => acc + (s.lessonsCompleted ?? 0), 0);

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#F2F2F7" }}
      contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Parent mode banner */}
      <View
        style={{
          backgroundColor: "#6B5CF6",
          paddingTop: insets.top + 8,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => router.back()}
            style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: "rgba(255,255,255,0.18)", alignItems: "center", justifyContent: "center" }}
          >
            <ArrowLeft size={18} color="#FFFFFF" />
          </TouchableOpacity>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.18)", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 }}>
            <Shield size={12} color="#FFFFFF" />
            <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("portalBadge")}</Text>
          </View>
          {unreadCount > 0 && (
            <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "#EF4444", alignItems: "center", justifyContent: "center" }}>
              <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>{unreadCount}</Text>
            </View>
          )}
          {unreadCount === 0 && <View style={{ width: 36 }} />}
        </View>

        {/* Greeting */}
        <View
          style={{
            width: 56,
            height: 56,
            borderRadius: 28,
            backgroundColor: parent.avatarColor ?? "rgba(255,255,255,0.2)",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 10,
            shadowColor: "#000",
            shadowOpacity: 0.15,
            shadowRadius: 8,
            elevation: 3,
          }}
        >
          <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>
            {parent.name?.[0] ?? "?"}
          </Text>
        </View>
        <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)", marginBottom: 2 }}>
          {t("parentWelcome")}
        </Text>
        <Text style={{ fontSize: 24, fontFamily: "Inter_700Bold", color: "#FFFFFF", letterSpacing: -0.5 }}>
          {parent.name}
        </Text>
      </View>

      {/* Summary stats */}
      <View
        style={{
          flexDirection: "row",
          paddingHorizontal: 20,
          gap: 10,
          marginTop: -1,
          marginBottom: 16,
          paddingTop: 16,
          backgroundColor: "#6B5CF6",
          borderBottomLeftRadius: 24,
          borderBottomRightRadius: 24,
        }}
      >
        {[
          { icon: BookOpen, label: t("parentStatLessons"), value: totalLessons, color: "#FFFFFF" },
          { icon: BarChart2, label: t("portalAvgScore"),    value: avgScore, color: "#FFFFFF" },
          { icon: FileText, label: t("parentStatReports"),  value: myReports.length, color: "#FFFFFF" },
        ].map(({ icon: Icon, label, value }) => (
          <View
            key={label}
            style={{
              flex: 1,
              backgroundColor: "rgba(255,255,255,0.18)",
              borderRadius: 14,
              padding: 12,
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Icon size={18} color="rgba(255,255,255,0.8)" />
            <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: "#FFFFFF", marginTop: 4 }}>
              {value}
            </Text>
            <Text style={{ fontSize: 10, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)", marginTop: 1 }}>
              {label}
            </Text>
          </View>
        ))}
      </View>

      {/* Children */}
      <View style={{ paddingHorizontal: 20, marginBottom: 8 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
            {myStudents.length === 1 ? t("parentMyChild") : t("parentMyChildren")}
          </Text>
        </View>
      </View>
      {myStudents.map((student) => (
        <ChildCard
          key={student.id}
          student={student}
          reports={myReports}
          lessons={lessons}
          onPress={() => router.push(`/progress/${student.id}?mode=parent&parentId=${parentId}`)}
        />
      ))}

      {/* Upcoming lessons */}
      {upcomingLessons.length > 0 && (
        <View style={{ marginHorizontal: 20, marginBottom: 14 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>{t("parentUpcomingLessons")}</Text>
            <Clock size={16} color="#8E8E93" />
          </View>
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              paddingHorizontal: 16,
              shadowColor: "#000",
              shadowOpacity: 0.04,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            {upcomingLessons.map((lesson) => {
              const sName = myStudents.find((s) =>
                (lesson.studentIds ?? []).includes(s.id)
              )?.name ?? "—";
              return (
                <UpcomingLessonRow
                  key={lesson.id}
                  lesson={lesson}
                  studentName={sName}
                />
              );
            })}
            <View style={{ height: 8 }} />
          </View>
        </View>
      )}

      {/* Recent reports */}
      <View style={{ paddingHorizontal: 20 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>{t("parentRecentReports")}</Text>
            {unreadCount > 0 && (
              <View style={{ paddingHorizontal: 8, paddingVertical: 3, backgroundColor: "#EF4444", borderRadius: 10 }}>
                <Text style={{ fontSize: 11, fontFamily: "Inter_700Bold", color: "#FFFFFF" }}>{t("newBadge", { n: unreadCount })}</Text>
              </View>
            )}
          </View>
          {myReports.length > 3 && (
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => router.push(`/parent-portal/reports?parentId=${parentId}`)}
              style={{ flexDirection: "row", alignItems: "center", gap: 2 }}
            >
              <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "#6B5CF6" }}>{t("all")}</Text>
              <ChevronRight size={13} color="#6B5CF6" />
            </TouchableOpacity>
          )}
        </View>

        {myReports.length === 0 ? (
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 32,
              alignItems: "center",
              shadowColor: "#000",
              shadowOpacity: 0.04,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <FileText size={28} color="#C7C7CC" />
            <Text style={{ fontSize: 14, fontFamily: "Inter_500Medium", color: "#8E8E93", marginTop: 12, textAlign: "center" }}>
              {t("portalReportsEmpty")}
            </Text>
          </View>
        ) : (
          myReports.slice(0, 5).map((report) => (
            <ReportPreviewCard
              key={report.id}
              report={report}
              isNew={!report.isRead}
              onPress={() => {
                markAsRead(report.id);
                router.push(`/parent-portal/report/${report.id}?parentId=${parentId}`);
              }}
            />
          ))
        )}
      </View>
    </ScrollView>
  );
}
