import { getFunctions, httpsCallable } from 'firebase/functions';
import { firebaseApp } from './config';

let _fns = null;

function fns() {
  if (!firebaseApp) throw new Error('Firebase не настроен');
  if (!_fns) _fns = getFunctions(firebaseApp, 'us-central1');
  return _fns;
}

// Sends a 6-digit OTP to the given email via Cloud Function.
// Throws with e.message set to a Russian user-friendly string on failure.
export async function sendVerificationCode({ email, firstName }) {
  const fn = httpsCallable(fns(), 'sendVerificationCode');
  const result = await fn({ email, firstName });
  return result.data;
}

// Verifies the OTP and, if valid, creates the Firebase Auth user + Firestore docs
// on the server. Returns { customToken, uid, parentCode }.
// The client must call signInWithCustomToken(auth, customToken) afterwards.
export async function verifyCodeAndCreateUser({ email, code, firstName, lastName, password, role }) {
  const fn = httpsCallable(fns(), 'verifyCodeAndCreateUser');
  const result = await fn({ email, code, firstName, lastName, password, role });
  return result.data;
}
