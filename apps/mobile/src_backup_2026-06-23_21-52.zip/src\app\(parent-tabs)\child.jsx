import { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  BookOpen,
  Calendar,
  FileText,
  Star,
  CheckCircle2,
  Clock,
  TrendingUp,
  Award,
  Target,
  ChevronRight,
  BarChart2,
  Users,
} from "lucide-react-native";
import { auth } from "../../utils/firebase/config";
import { getParentAccess, loadTeacherStore } from "../../utils/firebase/roles";
import { useT } from "../../utils/i18n";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const pad = (n) => String(n).padStart(2, "0");

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function formatDateFull(s, monthsArr) {
  if (!s) return "—";
  const [, m, d] = s.split("-").map(Number);
  return `${d} ${monthsArr[m - 1]}`;
}

function formatRelative(s, monthsArr, todayLabel, tomorrowLabel) {
  if (!s) return "—";
  const today = todayStr();
  const tomorrow = (() => {
    const d = new Date(); d.setDate(d.getDate() + 1);
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  })();
  if (s === today) return todayLabel;
  if (s === tomorrow) return tomorrowLabel;
  return formatDateFull(s, monthsArr);
}

function makeScoreCfg(t) {
  return {
    5: { label: t("scoreExcellent"), color: "#22C55E", bg: "#F0FDF4", bar: "#22C55E" },
    4: { label: t("scoreGood"),      color: "#3B82F6", bg: "#EFF6FF", bar: "#3B82F6" },
    3: { label: t("scoreMedium"),    color: "#F59E0B", bg: "#FFFBEB", bar: "#F59E0B" },
    2: { label: t("scorePoor"),      color: "#F97316", bg: "#FFF7ED", bar: "#F97316" },
    1: { label: t("scoreBad"),       color: "#EF4444", bg: "#FEF2F2", bar: "#EF4444" },
  };
}

// ─── Small components ─────────────────────────────────────────────────────────
function SectionTitle({ children, action, onAction }) {
  return (
    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginHorizontal: 20, marginBottom: 10, marginTop: 20 }}>
      <Text style={{ fontSize: 17, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>{children}</Text>
      {action && (
        <TouchableOpacity onPress={onAction} style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "#0EA5E9" }}>{action}</Text>
          <ChevronRight size={13} color="#0EA5E9" />
        </TouchableOpacity>
      )}
    </View>
  );
}

function StatChip({ icon: Icon, label, value, color, bg }) {
  return (
    <View style={{ flex: 1, backgroundColor: bg, borderRadius: 14, padding: 12, alignItems: "center", gap: 4 }}>
      <Icon size={17} color={color} />
      <Text style={{ fontSize: 19, fontFamily: "Inter_700Bold", color }}>{value}</Text>
      <Text style={{ fontSize: 10, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center" }}>{label}</Text>
    </View>
  );
}

// ─── Score bar chart from last 7 reports ─────────────────────────────────────
function ScoreChart({ reports }) {
  const { t, tp } = useT();
  const SCORE_CFG = makeScoreCfg(t);
  const last7 = [...reports].sort((a, b) => b.createdAt - a.createdAt).slice(0, 7).reverse();
  if (last7.length === 0) return null;
  const avg = (last7.reduce((s, r) => s + (r.activityScore ?? 3), 0) / last7.length).toFixed(1);
  const avgCfg = SCORE_CFG[Math.round(parseFloat(avg))] ?? SCORE_CFG[3];

  return (
    <View style={{ marginHorizontal: 20, backgroundColor: "#FFFFFF", borderRadius: 20, padding: 18, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <View>
          <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "#8E8E93" }}>{t("childScoreChart")}</Text>
          <View style={{ flexDirection: "row", alignItems: "baseline", gap: 6, marginTop: 2 }}>
            <Text style={{ fontSize: 28, fontFamily: "Inter_700Bold", color: avgCfg.color }}>{avg}</Text>
            <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>/ 5</Text>
          </View>
        </View>
        <View style={{ paddingHorizontal: 12, paddingVertical: 6, backgroundColor: avgCfg.bg, borderRadius: 20 }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: avgCfg.color }}>{avgCfg.label}</Text>
        </View>
      </View>

      {/* Bars */}
      <View style={{ flexDirection: "row", alignItems: "flex-end", gap: 6, height: 64 }}>
        {last7.map((r, i) => {
          const score = r.activityScore ?? 3;
          const cfg = SCORE_CFG[score] ?? SCORE_CFG[3];
          const h = (score / 5) * 56;
          return (
            <View key={i} style={{ flex: 1, alignItems: "center", gap: 4 }}>
              <View style={{ width: "100%", height: h, borderRadius: 6, backgroundColor: cfg.bar, opacity: i === last7.length - 1 ? 1 : 0.55 }} />
              <View style={{ flexDirection: "row", gap: 1 }}>
                {[1,2,3,4,5].map(s => (
                  <Star key={s} size={6} color={s <= score ? cfg.color : "#E5E5EA"} fill={s <= score ? cfg.color : "transparent"} />
                ))}
              </View>
            </View>
          );
        })}
      </View>
      <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: "#C7C7CC", marginTop: 6, textAlign: "center" }}>
        {tp(last7.length, "childLastNLessons")}
      </Text>
    </View>
  );
}

// ─── Upcoming lesson card ─────────────────────────────────────────────────────
function LessonCard({ lesson, monthsShort }) {
  const { t } = useT();
  return (
    <View style={{ marginHorizontal: 20, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 14, marginBottom: 8, flexDirection: "row", alignItems: "center", gap: 12, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8, elevation: 1 }}>
      <View style={{ width: 44, height: 44, borderRadius: 13, backgroundColor: "#E0F2FE", alignItems: "center", justifyContent: "center" }}>
        <BookOpen size={19} color="#0EA5E9" />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#1C1C1E" }}>{lesson.subject}</Text>
        <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
          {formatRelative(lesson.date, monthsShort, t("today"), t("tomorrow"))}{lesson.time ? `, ${lesson.time}` : ""} · {lesson.format ?? ""}
        </Text>
      </View>
      <View style={{ paddingHorizontal: 10, paddingVertical: 4, backgroundColor: "#E0F2FE", borderRadius: 20 }}>
        <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: "#0EA5E9" }}>{lesson.duration ?? 60} {t("min_abbr")}</Text>
      </View>
    </View>
  );
}

// ─── Homework card ────────────────────────────────────────────────────────────
function HomeworkCard({ report, monthsShort }) {
  const { t } = useT();
  return (
    <View style={{ marginHorizontal: 20, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 14, marginBottom: 8, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8, elevation: 1 }}>
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <CheckCircle2 size={14} color="#22C55E" />
          <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: "#22C55E" }}>{t("childHW")}</Text>
        </View>
        <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: "#C7C7CC" }}>{formatDateFull(report.date, monthsShort)}</Text>
      </View>
      <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#1C1C1E", lineHeight: 20 }}>{report.homework}</Text>
      <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 4 }}>{t("childHWTopic")}: {report.topic}</Text>
    </View>
  );
}

// ─── Report card ──────────────────────────────────────────────────────────────
function ReportCard({ report, monthsShort }) {
  const { t } = useT();
  const SCORE_CFG = makeScoreCfg(t);
  const cfg = SCORE_CFG[report.activityScore] ?? SCORE_CFG[3];
  return (
    <View style={{ marginHorizontal: 20, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 14, marginBottom: 8, borderLeftWidth: 3, borderLeftColor: cfg.color, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8, elevation: 1 }}>
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
        <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "#1C1C1E", flex: 1 }} numberOfLines={1}>{report.topic}</Text>
        <View style={{ paddingHorizontal: 8, paddingVertical: 3, backgroundColor: cfg.bg, borderRadius: 10, marginLeft: 8 }}>
          <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: cfg.color }}>{cfg.label}</Text>
        </View>
      </View>
      <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
        {formatDateFull(report.date, monthsShort)} · {report.subject}
      </Text>
      {report.comment ? (
        <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#3C3C43", marginTop: 6, lineHeight: 18 }} numberOfLines={2}>
          {report.comment}
        </Text>
      ) : null}
    </View>
  );
}

// ─── Child selector ───────────────────────────────────────────────────────────
function ChildSelector({ children, selected, onSelect }) {
  if (children.length <= 1) return null;
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }} contentContainerStyle={{ paddingHorizontal: 20, gap: 8, flexDirection: "row" }}>
      {children.map((c) => (
        <TouchableOpacity
          key={c.id}
          onPress={() => onSelect(c)}
          style={{
            flexDirection: "row", alignItems: "center", gap: 8,
            paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
            backgroundColor: selected?.id === c.id ? "#0EA5E9" : "#F2F2F7",
          }}
        >
          <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: selected?.id === c.id ? "rgba(255,255,255,0.3)" : (c.avatarColor ?? "#0EA5E9"), alignItems: "center", justifyContent: "center" }}>
            <Text style={{ fontSize: 10, fontFamily: "Inter_700Bold", color: "#FFF" }}>{c.name?.[0]}</Text>
          </View>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: selected?.id === c.id ? "#FFF" : "#1C1C1E" }}>{c.name}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

// ─── Main screen ──────────────────────────────────────────────────────────────
export default function ParentChild() {
  const insets = useSafeAreaInsets();
  const uid = auth?.currentUser?.uid;
  const { t, months } = useT();
  const monthsShort = months(true);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [children, setChildren] = useState([]);
  const [selectedChild, setSelectedChild] = useState(null);
  const [allLessons, setAllLessons] = useState([]);
  const [allReports, setAllReports] = useState([]);

  const loadData = useCallback(async () => {
    if (!uid) { setLoading(false); return; }
    try {
      const links = await getParentAccess(uid);
      const studs = [], lessons = [], reports = [];
      await Promise.all(
        links.map(async ({ teacherUid, studentIds }) => {
          const allowed = new Set(studentIds.map(String));
          const [s, l, r] = await Promise.all([
            loadTeacherStore(teacherUid, "students"),
            loadTeacherStore(teacherUid, "lessons"),
            loadTeacherStore(teacherUid, "reports"),
          ]);
          if (s) studs.push(...s.filter((x) => allowed.has(String(x.id))));
          if (l) lessons.push(...l);
          if (r) reports.push(...r.filter((x) => allowed.has(String(x.studentId))));
        })
      );
      setChildren(studs);
      setAllLessons(lessons);
      setAllReports(reports);
      setSelectedChild((prev) => prev ? studs.find((s) => s.id === prev.id) ?? studs[0] ?? null : studs[0] ?? null);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [uid]);

  useEffect(() => { loadData(); }, [loadData]);

  const onRefresh = () => { setRefreshing(true); loadData(); };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: "#F2F2F7", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color="#0EA5E9" />
      </View>
    );
  }

  if (children.length === 0) {
    return (
      <View style={{ flex: 1, backgroundColor: "#F2F2F7", alignItems: "center", justifyContent: "center", paddingHorizontal: 40 }}>
        <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: "#E0F2FE", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
          <Users size={32} color="#0EA5E9" />
        </View>
        <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", textAlign: "center", marginBottom: 8 }}>
          {t("parentNoChildren")}
        </Text>
        <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20 }}>
          {t("parentNoChildrenHint")}
        </Text>
      </View>
    );
  }

  const child = selectedChild;
  const childId = String(child?.id ?? "");

  const myReports = allReports
    .filter((r) => String(r.studentId) === childId)
    .sort((a, b) => b.createdAt - a.createdAt);

  const today = todayStr();
  const upcomingLessons = allLessons
    .filter((l) => (l.studentIds ?? []).includes(childId) && l.date >= today && l.status === "planned")
    .sort((a, b) => `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`))
    .slice(0, 3);

  const recentHomework = myReports.filter((r) => r.homework).slice(0, 3);
  const recentReports = myReports.slice(0, 5);

  const totalLessons = child?.lessonsCompleted ?? 0;
  const attendance = child?.attendance ?? 0;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#F2F2F7" }}
      contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
      showsVerticalScrollIndicator={false}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#0EA5E9" />}
    >
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <View style={{ backgroundColor: "#0EA5E9", paddingTop: insets.top + 16, paddingHorizontal: 20, paddingBottom: 32, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 }}>
        <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: "rgba(255,255,255,0.7)", marginBottom: 16, textTransform: "uppercase", letterSpacing: 0.6 }}>
          {t("parentChildTitle")}
        </Text>

        {child && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
            <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: child.avatarColor ?? "#38BDF8", alignItems: "center", justifyContent: "center", borderWidth: 3, borderColor: "rgba(255,255,255,0.4)" }}>
              <Text style={{ fontSize: 24, fontFamily: "Inter_700Bold", color: "#FFF" }}>{child.name?.[0]}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#FFF", marginBottom: 2 }}>{child.name}</Text>
              <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.75)" }}>
                {child.subject ?? child.type ?? "—"}
              </Text>
            </View>
          </View>
        )}
      </View>

      {/* ── Child selector (if multiple) ───────────────────────────────── */}
      <View style={{ marginTop: 16 }}>
        <ChildSelector children={children} selected={selectedChild} onSelect={setSelectedChild} />
      </View>

      {/* ── Stats ──────────────────────────────────────────────────────── */}
      <View style={{ flexDirection: "row", gap: 10, marginHorizontal: 20, marginTop: 16, marginBottom: 4 }}>
        <StatChip icon={BookOpen} label={t("parentStatLessons")} value={totalLessons} color="#0EA5E9" bg="#E0F2FE" />
        <StatChip icon={BarChart2} label={t("parentStatAttend")} value={`${attendance}%`} color="#22C55E" bg="#F0FDF4" />
        <StatChip icon={FileText} label={t("parentStatReports")} value={myReports.length} color="#6B5CF6" bg="#EEF0FF" />
        <StatChip icon={Star} label={t("childAvgScore")}
          value={myReports.length > 0 ? (myReports.reduce((s, r) => s + (r.activityScore ?? 3), 0) / myReports.length).toFixed(1) : "—"}
          color="#F59E0B" bg="#FFFBEB" />
      </View>

      {/* ── Score chart ────────────────────────────────────────────────── */}
      {myReports.length > 0 && (
        <>
          <SectionTitle>{t("childScoreDynamic")}</SectionTitle>
          <ScoreChart reports={myReports} />
        </>
      )}

      {/* ── Upcoming lessons ───────────────────────────────────────────── */}
      {upcomingLessons.length > 0 && (
        <>
          <SectionTitle>{t("parentUpcomingLessons")}</SectionTitle>
          {upcomingLessons.map((l) => <LessonCard key={l.id} lesson={l} monthsShort={monthsShort} />)}
        </>
      )}

      {upcomingLessons.length === 0 && (
        <>
          <SectionTitle>{t("parentUpcomingLessons")}</SectionTitle>
          <View style={{ marginHorizontal: 20, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 20, alignItems: "center" }}>
            <Calendar size={24} color="#C7C7CC" />
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 8 }}>{t("childNoLessons")}</Text>
          </View>
        </>
      )}

      {/* ── Homework ───────────────────────────────────────────────────── */}
      {recentHomework.length > 0 && (
        <>
          <SectionTitle>{t("childHW")}</SectionTitle>
          {recentHomework.map((r) => <HomeworkCard key={r.id} report={r} monthsShort={monthsShort} />)}
        </>
      )}

      {/* ── Recent reports ─────────────────────────────────────────────── */}
      {recentReports.length > 0 && (
        <>
          <SectionTitle>{t("parentRecentReports")}</SectionTitle>
          {recentReports.map((r) => <ReportCard key={r.id} report={r} monthsShort={monthsShort} />)}
        </>
      )}

      {myReports.length === 0 && (
        <>
          <SectionTitle>{t("parentRecentReports")}</SectionTitle>
          <View style={{ marginHorizontal: 20, backgroundColor: "#FFFFFF", borderRadius: 16, padding: 20, alignItems: "center" }}>
            <FileText size={24} color="#C7C7CC" />
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 8, textAlign: "center" }}>
              {t("childReportsEmpty")}
            </Text>
          </View>
        </>
      )}
    </ScrollView>
  );
}
