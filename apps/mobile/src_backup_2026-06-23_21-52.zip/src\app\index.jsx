import { useEffect, useState } from "react";
import { View, ActivityIndicator } from "react-native";
import { Redirect } from "expo-router";
import { onAuthStateChanged } from "firebase/auth";
import { auth, IS_FIREBASE_READY } from "@/utils/firebase/config";
import { getUserDoc } from "@/utils/firebase/users";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Possible states:
// "loading"    — waiting for Firebase auth + role check
// "onboarding" — first launch, show tutorial
// "no-auth"    — not logged in → role-select
// "teacher"    → /(tabs)
// "parent"     → /(parent-tabs)

export default function Index() {
  const [status, setStatus] = useState("loading");

  useEffect(() => {
    let cancelled = false;

    if (!IS_FIREBASE_READY || !auth) {
      // No Firebase config — check onboarding then fall through to role-select
      AsyncStorage.getItem("onboardingDone").then(done => {
        if (!cancelled) setStatus(done ? "no-auth" : "onboarding");
      });
      return;
    }

    const unsub = onAuthStateChanged(auth, async (user) => {
      if (cancelled) return;

      // Always check onboarding first
      let done = null;
      try { done = await AsyncStorage.getItem("onboardingDone"); } catch {}
      if (!done) { if (!cancelled) setStatus("onboarding"); return; }

      if (!user) { if (!cancelled) setStatus("no-auth"); return; }

      // Try cache for instant redirect
      try {
        const cached = await AsyncStorage.getItem("userRole");
        if (cached === "parent")  { if (!cancelled) setStatus("parent");  return; }
        if (cached === "teacher") { if (!cancelled) setStatus("teacher"); return; }
      } catch {}

      // Fallback to Firestore
      const userData = await getUserDoc(user.uid);
      const role = userData?.role ?? "teacher";
      AsyncStorage.setItem("userRole", role).catch(() => {});
      if (!cancelled) setStatus(role === "parent" ? "parent" : "teacher");
    });

    return () => {
      cancelled = true;
      unsub();
    };
  }, []);

  if (status === "loading") {
    return (
      <View style={{ flex: 1, backgroundColor: "#6B5CF6", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color="#FFFFFF" size="large" />
      </View>
    );
  }

  if (status === "onboarding") return <Redirect href="/onboarding" />;
  if (status === "no-auth")    return <Redirect href="/role-select" />;
  if (status === "parent")     return <Redirect href="/(parent-tabs)" />;
  return <Redirect href="/(tabs)" />;
}
