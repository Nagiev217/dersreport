import { create } from 'zustand';

// Non-persisted store for pending email registration.
// Holds form data between register.jsx and verify-email.jsx.
// Cleared automatically after account creation.
export const useRegistrationStore = create((set) => ({
  pending: null,
  setPending: (data) => set({ pending: data }),
  clear: () => set({ pending: null }),
}));
