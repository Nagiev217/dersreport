import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState, useMemo } from "react";
import { useRouter } from "expo-router";
import {
  BookOpen,
  Clock,
  Video,
  Globe,
  Hash,
  GraduationCap,
  Calendar,
  Plus,
  Timer,
  Archive,
  Banknote,
  CreditCard,
  Smartphone,
  TrendingUp,
  Trash2,
} from "lucide-react-native";
import SearchBar from "@/components/SearchBar";
import FilterChips from "@/components/FilterChips";
import { useLessonsStore } from "@/utils/lessons/store";
import { usePaymentsStore } from "@/utils/payments/store";
import AddPaymentModal from "@/components/AddPaymentModal";
import { useT, useDateLocale } from "@/utils/i18n";
import {
  formatDateShort,
  formatDateFull,
  todayStr,
  toDateStr,
} from "@/utils/dateUtils";

// ─── Constants ────────────────────────────────────────────────────────────────

// Filter keys (translated inside component)
const ACTIVE_FILTER_KEYS  = ["all", "today", "tomorrow", "upcoming"];
const ARCHIVE_FILTER_KEYS = ["all", "done", "cancelled"];

// METHOD_CONFIG labels are translated inside PaymentCard

const SUBJECT_CONFIG = {
  IELTS:      { Icon: BookOpen,     color: "#6B5CF6", bg: "#EEF0FF" },
  SAT:        { Icon: Hash,         color: "#3B82F6", bg: "#EFF6FF" },
  General:    { Icon: Globe,        color: "#10B981", bg: "#ECFDF5" },
  Английский: { Icon: GraduationCap, color: "#F59E0B", bg: "#FFFBEB" },
};

// STATUS_CONFIG is computed inside LessonCard (needs t())

// ─── Helpers ──────────────────────────────────────────────────────────────────

function lessonEndTime(lesson) {
  const [h, m] = (lesson.time ?? "00:00").split(":").map(Number);
  const d = new Date(`${lesson.date}T00:00:00`);
  d.setHours(h, m + (lesson.duration ?? 60), 0, 0);
  return d;
}

// A lesson is "archived" when it has fully ended or was completed/cancelled
function isArchived(lesson, now) {
  if (lesson.status === "completed" || lesson.status === "cancelled") return true;
  return lessonEndTime(lesson) < now;
}

// ─── LessonCard ───────────────────────────────────────────────────────────────

const LessonCard = ({ lesson, onPress, dimmed }) => {
  const { t } = useT();
  const locale = useDateLocale();
  const STATUS_CFG = {
    planned:   { label: t("statusPlanned"),   color: "#6B5CF6", bg: "#EEF0FF" },
    completed: { label: t("statusCompleted"), color: "#22C55E", bg: "#F0FDF4" },
    cancelled: { label: t("statusCancelled"), color: "#EF4444", bg: "#FEF2F2" },
  };
  const subjectCfg = SUBJECT_CONFIG[lesson.subject] || SUBJECT_CONFIG.Английский;
  const statusCfg  = STATUS_CFG[lesson.status] || STATUS_CFG.planned;
  const SubjectIcon = subjectCfg.Icon;

  const names = Array.isArray(lesson.studentNames)
    ? lesson.studentNames.join(" · ")
    : lesson.student ?? "—";

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 16,
        opacity: dimmed ? 0.72 : 1,
        shadowColor: "#000",
        shadowOpacity: 0.06,
        shadowRadius: 8,
        shadowOffset: { width: 0, height: 2 },
        elevation: 2,
      }}
    >
      {/* Row 1: subject + status */}
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: subjectCfg.bg, alignItems: "center", justifyContent: "center" }}>
            <SubjectIcon size={18} color={subjectCfg.color} />
          </View>
          <Text style={{ fontSize: 16, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
            {lesson.subject}
          </Text>
        </View>
        <View style={{ paddingHorizontal: 10, paddingVertical: 4, backgroundColor: statusCfg.bg, borderRadius: 20 }}>
          <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: statusCfg.color }}>
            {statusCfg.label}
          </Text>
        </View>
      </View>

      {/* Row 2: students */}
      <Text style={{ fontSize: 14, fontFamily: "Inter_500Medium", color: "#3C3C43", marginBottom: 10 }} numberOfLines={1}>
        {names}
      </Text>

      {/* Row 3: time · duration · format */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Clock size={13} color="#8E8E93" />
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>{lesson.time}</Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Timer size={13} color="#8E8E93" />
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>{lesson.duration} {t("min_abbr")}</Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Video size={13} color="#6B5CF6" />
          <Text style={{ fontSize: 12, fontFamily: "Inter_500Medium", color: "#6B5CF6" }}>{lesson.format ?? t("online")}</Text>
        </View>
      </View>

      {/* Row 4: date */}
      {lesson.date && (
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 8, paddingTop: 8, borderTopWidth: 0.5, borderTopColor: "#F2F2F7" }}>
          <Calendar size={12} color="#8E8E93" />
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
            {formatDateFull(lesson.date, locale)}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

// ─── Empty states ─────────────────────────────────────────────────────────────

const EmptyActive = ({ filter, onAdd, filterToday, filterTmrw }) => {
  const { t } = useT();
  return (
    <View style={{ alignItems: "center", paddingTop: 48, paddingHorizontal: 32 }}>
      <View style={{ width: 72, height: 72, borderRadius: 22, backgroundColor: "#EEF0FF", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
        <BookOpen size={32} color="#6B5CF6" />
      </View>
      <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginBottom: 6, textAlign: "center" }}>
        {t("lessonsEmptyTitle")}
      </Text>
      <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20, marginBottom: 24 }}>
        {filter === filterToday ? t("lessonsEmptyFilterToday")
          : filter === filterTmrw ? t("lessonsEmptyFilterTmrw")
          : t("lessonsEmptyDefault")}
      </Text>
      <TouchableOpacity activeOpacity={0.85} onPress={onAdd} style={{ paddingHorizontal: 24, paddingVertical: 12, backgroundColor: "#6B5CF6", borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 8 }}>
        <Plus size={16} color="#FFFFFF" />
        <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("lessonsAddBtn")}</Text>
      </TouchableOpacity>
    </View>
  );
};

const EmptyArchive = () => {
  const { t } = useT();
  return (
    <View style={{ alignItems: "center", paddingTop: 48, paddingHorizontal: 32 }}>
      <View style={{ width: 72, height: 72, borderRadius: 22, backgroundColor: "#F2F2F7", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
        <Archive size={32} color="#8E8E93" />
      </View>
      <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginBottom: 6, textAlign: "center" }}>
        {t("lessonsArchiveEmpty")}
      </Text>
      <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20 }}>
        {t("lessonsArchiveEmptyHint")}
      </Text>
    </View>
  );
};

// ─── PaymentCard ──────────────────────────────────────────────────────────────

const PaymentCard = ({ payment, onDelete }) => {
  const METHOD_CFG = {
    cash:     { Icon: Banknote,   color: "#22C55E", bg: "#F0FDF4" },
    card:     { Icon: CreditCard, color: "#3B82F6", bg: "#EFF6FF" },
    transfer: { Icon: Smartphone, color: "#8B5CF6", bg: "#F5F3FF" },
  };
  const METHOD_LABELS = { cash: "addPayCash", card: "addPayCard", transfer: "addPayTransfer" };
  const cfg = METHOD_CFG[payment.method] ?? METHOD_CFG.cash;
  const MethodIcon = cfg.Icon;

  const initials = (payment.studentName ?? "?")
    .split(" ")
    .map(w => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const { t } = useT();

  function confirmDelete() {
    Alert.alert(t("addPayDeleteTitle"), t("addPayDeleteMsg"), [
      { text: t("cancel"), style: "cancel" },
      { text: t("delete"), style: "destructive", onPress: () => onDelete(payment.id) },
    ]);
  }

  return (
    <View style={{ backgroundColor: "#FFFFFF", borderRadius: 16, padding: 14,
      shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 6, shadowOffset: { width: 0, height: 2 }, elevation: 2,
      flexDirection: "row", alignItems: "center", gap: 12 }}>
      {/* Avatar */}
      <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: "#EEF0FF",
        alignItems: "center", justifyContent: "center" }}>
        <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#6B5CF6" }}>{initials}</Text>
      </View>

      {/* Info */}
      <View style={{ flex: 1, gap: 3 }}>
        <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#1C1C1E" }} numberOfLines={1}>
          {payment.studentName}
        </Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4,
            paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8, backgroundColor: cfg.bg }}>
            <MethodIcon size={11} color={cfg.color} />
            <Text style={{ fontSize: 11, fontFamily: "Inter_500Medium", color: cfg.color }}>
              {t(METHOD_LABELS[payment.method] ?? "addPayCash")}
            </Text>
          </View>
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }}>
            {payment.date}
          </Text>
        </View>
        {payment.note ? (
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: "#8E8E93" }} numberOfLines={1}>
            {payment.note}
          </Text>
        ) : null}
      </View>

      {/* Amount + delete */}
      <View style={{ alignItems: "flex-end", gap: 8 }}>
        <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#22C55E" }}>
          +{payment.amount} ₼
        </Text>
        <TouchableOpacity activeOpacity={0.7} onPress={confirmDelete}>
          <Trash2 size={14} color="#C7C7CC" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const EmptyPayments = ({ onAdd }) => {
  const { t } = useT();
  return (
    <View style={{ alignItems: "center", paddingTop: 48, paddingHorizontal: 32 }}>
      <View style={{ width: 72, height: 72, borderRadius: 22, backgroundColor: "#ECFDF5", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
        <Banknote size={32} color="#22C55E" />
      </View>
      <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: "#1C1C1E", marginBottom: 6, textAlign: "center" }}>
        {t("paymentsEmptyTitle")}
      </Text>
      <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", textAlign: "center", lineHeight: 20, marginBottom: 24 }}>
        {t("paymentsEmptyHint")}
      </Text>
      <TouchableOpacity activeOpacity={0.85} onPress={onAdd} style={{ paddingHorizontal: 24, paddingVertical: 12, backgroundColor: "#22C55E", borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 8 }}>
        <Plus size={16} color="#FFFFFF" />
        <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>{t("paymentsAddBtn")}</Text>
      </TouchableOpacity>
    </View>
  );
};

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function LessonsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { t, tp } = useT();
  const locale = useDateLocale();

  const [tab,          setTab]          = useState("active"); // "active" | "archive" | "payments"
  const [search,       setSearch]       = useState("");
  const [filter,       setFilter]       = useState(null); // null = first filter (translated dynamically)
  const [showAddPay,   setShowAddPay]   = useState(false);

  const ACTIVE_FILTERS  = [t("all"), t("lessonsFilterToday"), t("lessonsFilterTmrw"), t("lessonsFilterUpcoming")];
  const ARCHIVE_FILTERS = [t("all"), t("lessonsFilterDone"), t("lessonsFilterCancelled")];
  const filterAll       = t("all");
  const filterToday     = t("lessonsFilterToday");
  const filterTmrw      = t("lessonsFilterTmrw");
  const filterUpcoming  = t("lessonsFilterUpcoming");
  const filterDone      = t("lessonsFilterDone");
  const filterCancelled = t("lessonsFilterCancelled");

  // Normalize filter: null or stale-lang value → treat as "All"
  const activeFilter = filter ?? filterAll;

  const { lessons } = useLessonsStore();
  const { payments, deletePayment } = usePaymentsStore();

  const now      = new Date();
  const today    = todayStr();
  const tomorrow = toDateStr((() => { const d = new Date(); d.setDate(d.getDate() + 1); return d; })());

  // Split into active / archived
  const { active, archived } = useMemo(() => {
    const active   = [];
    const archived = [];
    for (const l of lessons) {
      if (isArchived(l, now)) archived.push(l);
      else active.push(l);
    }
    // archived: newest first
    archived.sort((a, b) => `${b.date}${b.time}`.localeCompare(`${a.date}${a.time}`));
    return { active, archived };
  }, [lessons]);

  // Switch tab → reset filter
  function switchTab(newTab) {
    setTab(newTab);
    setFilter(null);
    setSearch("");
  }

  // Active filters
  const filteredActive = useMemo(() => {
    let list = active;
    if (activeFilter === filterToday)       list = list.filter(l => l.date === today);
    else if (activeFilter === filterTmrw)   list = list.filter(l => l.date === tomorrow);
    else if (activeFilter === filterUpcoming) list = list.filter(l => l.date >= today);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(l =>
        l.subject.toLowerCase().includes(q) ||
        (l.studentNames ?? []).some(n => n.toLowerCase().includes(q)) ||
        (l.student ?? "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [active, activeFilter, search, today, tomorrow, filterToday, filterTmrw, filterUpcoming]);

  // Archive filters
  const filteredArchive = useMemo(() => {
    let list = archived;
    if (activeFilter === filterDone)           list = list.filter(l => l.status === "completed");
    else if (activeFilter === filterCancelled) list = list.filter(l => l.status === "cancelled");
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(l =>
        l.subject.toLowerCase().includes(q) ||
        (l.studentNames ?? []).some(n => n.toLowerCase().includes(q)) ||
        (l.student ?? "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [archived, activeFilter, search, filterDone, filterCancelled]);

  // Payment stats
  const currentPeriod = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const { thisMonthTotal, allTimeTotal, filteredPayments } = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = payments
      .slice()
      .sort((a, b) => b.date.localeCompare(a.date));
    const filtered = q
      ? list.filter(p => (p.studentName ?? "").toLowerCase().includes(q))
      : list;
    const thisMonth = list.filter(p => p.period === currentPeriod);
    return {
      thisMonthTotal:   thisMonth.reduce((s, p) => s + (p.amount ?? 0), 0),
      allTimeTotal:     list.reduce((s, p) => s + (p.amount ?? 0), 0),
      filteredPayments: filtered,
    };
  }, [payments, search, currentPeriod]);

  // Summary stats
  const todayLessons = useMemo(() => lessons.filter(l => l.date === today && l.status !== "cancelled"), [lessons, today]);
  const nextUpcoming = useMemo(() => active.filter(l => l.status === "planned").sort((a, b) =>
    new Date(`${a.date}T${a.time}:00`) - new Date(`${b.date}T${b.time}:00`)
  )[0], [active]);

  const handleAdd  = () => router.push("/lesson/add");
  const handleOpen = (id) => router.push(`/lesson/${id}`);

  const currentFilters  = tab === "active" ? ACTIVE_FILTERS : ARCHIVE_FILTERS;
  const currentFiltered = tab === "active" ? filteredActive  : filteredArchive;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: "#F2F2F7" }}
      contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
      showsVerticalScrollIndicator={false}
    >
      {/* ── Header ──────────────────────────────────────────────────── */}
      <View style={{ paddingTop: insets.top + 12, paddingHorizontal: 20, marginBottom: 4 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
          <View>
            <Text style={{ fontSize: 32, fontFamily: "Inter_700Bold", color: "#1C1C1E", letterSpacing: -0.5 }}>
              {t("lessonsTitle")}
            </Text>
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#8E8E93", marginTop: 2 }}>
              {tab === "active"
                ? t("lessonsSubtitle")
                : tab === "archive"
                ? `${t("lessonsInArchive")}${archived.length} ${tp(archived.length, "lesson")}`
                : `${t("lessonsArchiveMonthly")}${thisMonthTotal} ₼`}
            </Text>
          </View>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={tab === "payments" ? () => setShowAddPay(true) : handleAdd}
            style={{ width: 40, height: 40, borderRadius: 12,
              backgroundColor: tab === "payments" ? "#22C55E" : "#6B5CF6",
              alignItems: "center", justifyContent: "center", marginTop: 4 }}
          >
            <Plus size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        {/* Tab toggle */}
        <View style={{ flexDirection: "row", marginTop: 16, borderBottomWidth: 1, borderBottomColor: "#E5E5EA" }}>
          {[
            { id: "active",   label: t("lessonsTabActive"),   count: active.length },
            { id: "archive",  label: t("lessonsTabArchive"),  count: archived.length },
            { id: "payments", label: t("lessonsTabPayments"), count: payments.length },
          ].map(({ id, label, count }) => {
            const isActive = tab === id;
            return (
              <TouchableOpacity
                key={id}
                onPress={() => switchTab(id)}
                activeOpacity={0.7}
                style={{ flex: 1, paddingBottom: 12, alignItems: "center", position: "relative" }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  <Text style={{ fontSize: 14, fontFamily: isActive ? "Inter_600SemiBold" : "Inter_400Regular", color: isActive ? "#6B5CF6" : "#8E8E93" }}>
                    {label}
                  </Text>
                  {count > 0 && (
                    <View style={{ backgroundColor: isActive ? "#6B5CF6" : "#E5E5EA", borderRadius: 10, paddingHorizontal: 6, paddingVertical: 1 }}>
                      <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: isActive ? "#FFF" : "#8E8E93" }}>
                        {count}
                      </Text>
                    </View>
                  )}
                </View>
                {isActive && (
                  <View style={{ position: "absolute", bottom: 0, left: 20, right: 20, height: 2.5, borderRadius: 1.5, backgroundColor: "#6B5CF6" }} />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* ── Search ──────────────────────────────────────────────────── */}
      <View style={{ paddingHorizontal: 20, marginTop: 16, marginBottom: 14 }}>
        <SearchBar
          placeholder={
            tab === "payments" ? t("lessonsSearchPay")
            : tab === "archive" ? t("lessonsSearchArchive")
            : t("lessonsSearchActive")
          }
          value={search}
          onChangeText={setSearch}
          showMic={false}
        />
      </View>

      {/* ── Filter chips (lessons only) ──────────────────────────────── */}
      {tab !== "payments" && (
        <View style={{ paddingLeft: 20, marginBottom: 16 }}>
          <FilterChips
            options={currentFilters}
            selected={activeFilter}
            onSelect={setFilter}
          />
        </View>
      )}

      {/* ── Summary card (active tab only) ───────────────────────────── */}
      {tab === "active" && (
        <TouchableOpacity
          activeOpacity={0.9}
          style={{ marginHorizontal: 20, marginBottom: 16, backgroundColor: "#EEF0FF", borderRadius: 20, padding: 18, flexDirection: "row", alignItems: "center", gap: 14, shadowColor: "#6B5CF6", shadowOpacity: 0.08, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 3 }}
        >
          <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: "#DDD9FF", alignItems: "center", justifyContent: "center" }}>
            <BookOpen size={22} color="#6B5CF6" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontFamily: "Inter_700Bold", color: "#1C1C1E" }}>
              {todayLessons.length > 0 ? `${t("lessonsTodayCount")}${todayLessons.length}` : t("lessonsTodayNone")}
            </Text>
            <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#6B5CF6", marginTop: 2 }}>
              {nextUpcoming
                ? `${t("lessonsNearest")}${formatDateShort(nextUpcoming.date, locale)}, ${nextUpcoming.time}`
                : t("lessonsNoUpcoming")}
            </Text>
          </View>
        </TouchableOpacity>
      )}

      {/* ── Archive banner (archive tab) ─────────────────────────────── */}
      {tab === "archive" && archived.length > 0 && (
        <View style={{ marginHorizontal: 20, marginBottom: 16, backgroundColor: "#F8F7FF", borderRadius: 14, padding: 14, flexDirection: "row", alignItems: "center", gap: 12, borderWidth: 1, borderColor: "#E8E5FF" }}>
          <Archive size={18} color="#6B5CF6" />
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "#6B5CF6", flex: 1, lineHeight: 18 }}>
            {t("lessonsArchiveHint")}
          </Text>
        </View>
      )}

      {/* ── Payments tab ─────────────────────────────────────────────── */}
      {tab === "payments" && (
        <View style={{ paddingHorizontal: 20 }}>
          {/* Stats row */}
          {payments.length > 0 && (
            <View style={{ flexDirection: "row", gap: 10, marginBottom: 16 }}>
              <View style={{ flex: 1, backgroundColor: "#ECFDF5", borderRadius: 16, padding: 14, alignItems: "center", gap: 4 }}>
                <TrendingUp size={18} color="#22C55E" />
                <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#22C55E" }}>
                  {thisMonthTotal} ₼
                </Text>
                <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: "#6B7280", textAlign: "center" }}>
                  {t("lessonsThisMonth")}
                </Text>
              </View>
              <View style={{ flex: 1, backgroundColor: "#F5F3FF", borderRadius: 16, padding: 14, alignItems: "center", gap: 4 }}>
                <Banknote size={18} color="#8B5CF6" />
                <Text style={{ fontSize: 22, fontFamily: "Inter_700Bold", color: "#8B5CF6" }}>
                  {allTimeTotal} ₼
                </Text>
                <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: "#6B7280", textAlign: "center" }}>
                  {t("lessonsAllTime")}
                </Text>
              </View>
            </View>
          )}

          {/* Payment list */}
          <View style={{ gap: 10 }}>
            {filteredPayments.length === 0 ? (
              <EmptyPayments onAdd={() => setShowAddPay(true)} />
            ) : (
              filteredPayments.map(p => (
                <PaymentCard key={p.id} payment={p} onDelete={deletePayment} />
              ))
            )}
          </View>
        </View>
      )}

      {/* ── Lesson list ──────────────────────────────────────────────── */}
      {tab !== "payments" && (
        <View style={{ paddingHorizontal: 20, gap: 10 }}>
          {currentFiltered.length === 0 ? (
            tab === "active"
              ? <EmptyActive filter={filter} onAdd={handleAdd} filterToday={filterToday} filterTmrw={filterTmrw} />
              : <EmptyArchive />
          ) : (
            currentFiltered.map(lesson => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                onPress={() => handleOpen(lesson.id)}
                dimmed={tab === "archive"}
              />
            ))
          )}
        </View>
      )}

      {/* ── Add Payment modal ─────────────────────────────────────────── */}
      <AddPaymentModal
        visible={showAddPay}
        onClose={() => setShowAddPay(false)}
      />
    </ScrollView>
  );
}
