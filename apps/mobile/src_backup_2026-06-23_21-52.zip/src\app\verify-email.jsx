import { useState, useRef, useEffect, useCallback } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  Animated, Keyboard, ActivityIndicator,
  StatusBar, Platform, KeyboardAvoidingView,
  TouchableWithoutFeedback,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Mail, RefreshCw, ArrowLeft, CheckCircle2 } from "lucide-react-native";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/utils/firebase/config";
import { sendVerificationCode, verifyCodeAndCreateUser } from "@/utils/firebase/verification";
import { registerPushToken } from "@/utils/firebase/notifications";
import { useRegistrationStore } from "@/utils/auth/registrationStore";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useT } from "@/utils/i18n";

const OTP_LENGTH = 6;
const RESEND_TIMEOUT = 60;

const ROLE_META = {
  teacher: { gradient: ["#4F46E5", "#6B5CF6"], accent: "#6B5CF6" },
  parent:  { gradient: ["#0EA5E9", "#6366F1"], accent: "#0EA5E9" },
};

export default function VerifyEmailScreen() {
  const insets = useSafeAreaInsets();
  const pending  = useRegistrationStore((s) => s.pending);
  const clearPending = useRegistrationStore((s) => s.clear);
  const { t } = useT();

  const [otp, setOtp]             = useState("");
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState("");
  const [success, setSuccess]     = useState(false);
  const [countdown, setCountdown] = useState(RESEND_TIMEOUT);
  const [resending, setResending] = useState(false);

  const inputRef   = useRef(null);
  const shakeAnim  = useRef(new Animated.Value(0)).current;
  const successAnim = useRef(new Animated.Value(0)).current;

  // No pending data → user opened screen directly or app was killed; restart flow
  useEffect(() => {
    if (!pending) router.replace("/role-select");
  }, []);

  // Countdown for resend button
  useEffect(() => {
    if (countdown <= 0) return;
    const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [countdown]);

  const shake = useCallback(() => {
    shakeAnim.setValue(0);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10,  duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 7,   duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -7,  duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,   duration: 55, useNativeDriver: true }),
    ]).start();
  }, [shakeAnim]);

  const handleOtpChange = (text) => {
    const digits = text.replace(/[^0-9]/g, "").slice(0, OTP_LENGTH);
    setOtp(digits);
    setError("");
    if (digits.length === OTP_LENGTH) {
      Keyboard.dismiss();
      handleVerify(digits);
    }
  };

  const handleVerify = async (code) => {
    const codeToVerify = code ?? otp;
    if (codeToVerify.length !== OTP_LENGTH || loading || success || !pending) return;

    setLoading(true);
    setError("");
    try {
      const result = await verifyCodeAndCreateUser({
        email:     pending.email,
        code:      codeToVerify,
        firstName: pending.firstName,
        lastName:  pending.lastName,
        password:  pending.password,
        role:      pending.role,
      });

      // CF created the user — now sign in with the known credentials
      await signInWithEmailAndPassword(auth, pending.email, pending.password);
      await AsyncStorage.setItem("userRole", pending.role);

      registerPushToken(result.uid, pending.role).catch(() => {});

      setSuccess(true);
      Animated.spring(successAnim, {
        toValue: 1, tension: 60, friction: 8, useNativeDriver: true,
      }).start();

      setTimeout(() => {
        clearPending();
        router.replace(`/complete-profile?role=${pending.role}`);
      }, 900);
    } catch (e) {
      const msg = e.message || t("verifyErrDefault");
      setError(msg);
      setOtp("");
      shake();
      // Give focus back so user can type again
      setTimeout(() => inputRef.current?.focus(), 300);
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (countdown > 0 || resending || !pending) return;
    setResending(true);
    setError("");
    setOtp("");
    try {
      await sendVerificationCode({ email: pending.email, firstName: pending.firstName });
      setCountdown(RESEND_TIMEOUT);
      setTimeout(() => inputRef.current?.focus(), 200);
    } catch (e) {
      setError(e.message || t("verifyResendErr"));
    } finally {
      setResending(false);
    }
  };

  if (!pending) return null;

  const meta = ROLE_META[pending.role] ?? ROLE_META.teacher;
  const { gradient, accent } = meta;
  const filled = otp.length;

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
    <View style={{ flex: 1, backgroundColor: "#F2F2F7" }}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        {/* ── Hero gradient ────────────────────────────────────────────────── */}
        <LinearGradient
          colors={gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 0.6, y: 1 }}
          style={{
            paddingTop: insets.top + 16,
            paddingHorizontal: 28,
            paddingBottom: 52,
          }}
        >
          {/* Back */}
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              alignSelf: "flex-start",
              flexDirection: "row", alignItems: "center",
              gap: 6, marginBottom: 28, opacity: 0.8,
            }}
          >
            <ArrowLeft size={16} color="#FFFFFF" />
            <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: "#FFFFFF" }}>
              {t("back")}
            </Text>
          </TouchableOpacity>

          {/* Icon */}
          <Animated.View style={{
            alignItems: "center",
            transform: [{ scale: success
              ? successAnim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [1, 1.3, 1] })
              : 1
            }],
          }}>
            <View style={{
              width: 72, height: 72, borderRadius: 22,
              backgroundColor: "rgba(255,255,255,0.2)",
              alignItems: "center", justifyContent: "center",
              marginBottom: 18,
              borderWidth: 1.5, borderColor: "rgba(255,255,255,0.35)",
            }}>
              {success
                ? <CheckCircle2 size={36} color="#FFFFFF" />
                : <Mail size={34} color="#FFFFFF" />
              }
            </View>
          </Animated.View>

          <Text style={{
            fontSize: 26, fontFamily: "Inter_700Bold", color: "#FFFFFF",
            textAlign: "center", marginBottom: 8,
          }}>
            {success ? t("verifySuccess") : t("verifyTitle")}
          </Text>
          <Text style={{
            fontSize: 14, fontFamily: "Inter_400Regular",
            color: "rgba(255,255,255,0.75)",
            textAlign: "center", lineHeight: 20,
          }}>
            {success
              ? t("verifyWelcome")
              : `${t("verifySentTo")}\n`
            }
            {!success && (
              <Text style={{ fontFamily: "Inter_600SemiBold", color: "#FFFFFF" }}>
                {pending.email}
              </Text>
            )}
          </Text>
        </LinearGradient>

        {/* ── OTP card ─────────────────────────────────────────────────────── */}
        {!success && (
          <View style={{
            marginTop: -24,
            marginHorizontal: 20,
            backgroundColor: "#FFFFFF",
            borderRadius: 26,
            padding: 28,
            shadowColor: "#000",
            shadowOpacity: 0.09,
            shadowRadius: 22,
            shadowOffset: { width: 0, height: 8 },
            elevation: 10,
          }}>
            {/* Digit boxes — tapping any box focuses the hidden input */}
            <Animated.View style={{ transform: [{ translateX: shakeAnim }] }}>
              <TouchableOpacity
                activeOpacity={1}
                onPress={() => inputRef.current?.focus()}
                style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 24 }}
              >
                {Array.from({ length: OTP_LENGTH }, (_, i) => {
                  const isActive = i === filled && !loading;
                  const hasDigit = i < filled;
                  return (
                    <View
                      key={i}
                      style={{
                        width: 46, height: 58, borderRadius: 15,
                        backgroundColor: isActive ? `${accent}12` : hasDigit ? "#F2F2F7" : "#F8F8F8",
                        borderWidth: 2,
                        borderColor: isActive ? accent : hasDigit ? "#C7C7CC" : "#E5E5EA",
                        alignItems: "center", justifyContent: "center",
                      }}
                    >
                      {hasDigit ? (
                        <Text style={{
                          fontSize: 26, fontFamily: "Inter_700Bold", color: "#1C1C1E",
                        }}>
                          {otp[i]}
                        </Text>
                      ) : isActive ? (
                        <View style={{
                          width: 2, height: 24, borderRadius: 1,
                          backgroundColor: accent, opacity: 0.8,
                        }} />
                      ) : null}
                    </View>
                  );
                })}
              </TouchableOpacity>
            </Animated.View>

            {/* Hidden TextInput captures all input */}
            <TextInput
              ref={inputRef}
              value={otp}
              onChangeText={handleOtpChange}
              keyboardType="number-pad"
              maxLength={OTP_LENGTH}
              caretHidden
              autoFocus
              style={{
                position: "absolute",
                width: 1, height: 1, opacity: 0,
                top: 0, left: 0,
              }}
            />

            {/* Error */}
            {!!error && (
              <View style={{
                backgroundColor: "#FEF2F2", borderRadius: 12,
                paddingHorizontal: 14, paddingVertical: 10,
                marginBottom: 16, borderWidth: 1, borderColor: "#FECACA",
              }}>
                <Text style={{
                  fontSize: 13, fontFamily: "Inter_400Regular",
                  color: "#EF4444", textAlign: "center",
                }}>
                  {error}
                </Text>
              </View>
            )}

            {/* Verify button */}
            <TouchableOpacity
              onPress={() => handleVerify()}
              disabled={filled < OTP_LENGTH || loading}
              activeOpacity={0.85}
              style={{
                height: 54, borderRadius: 16,
                backgroundColor: filled === OTP_LENGTH ? accent : "#E5E5EA",
                alignItems: "center", justifyContent: "center",
                marginBottom: 22,
              }}
            >
              {loading
                ? <ActivityIndicator color="#FFFFFF" />
                : <Text style={{
                    fontSize: 16, fontFamily: "Inter_700Bold",
                    color: filled === OTP_LENGTH ? "#FFFFFF" : "#8E8E93",
                  }}>
                    {t("verifyConfirmBtn")}
                  </Text>
              }
            </TouchableOpacity>

            {/* Resend */}
            <View style={{ alignItems: "center" }}>
              <Text style={{
                fontSize: 13, fontFamily: "Inter_400Regular",
                color: "#8E8E93", marginBottom: 8,
              }}>
                {t("verifyNoCode")}
              </Text>
              {countdown > 0 ? (
                <Text style={{
                  fontSize: 14, fontFamily: "Inter_500Medium", color: "#C7C7CC",
                }}>
                  {t("verifyResendIn", { n: countdown })}
                </Text>
              ) : (
                <TouchableOpacity
                  onPress={handleResend}
                  disabled={resending}
                  style={{ flexDirection: "row", alignItems: "center", gap: 7 }}
                >
                  {resending
                    ? <ActivityIndicator size="small" color={accent} />
                    : <RefreshCw size={14} color={accent} />
                  }
                  <Text style={{
                    fontSize: 14, fontFamily: "Inter_600SemiBold", color: accent,
                  }}>
                    {resending ? t("verifySending") : t("verifyResend")}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}

        {/* ── Hint ─────────────────────────────────────────────────────────── */}
        {!success && (
          <Text style={{
            textAlign: "center", fontSize: 12,
            fontFamily: "Inter_400Regular", color: "#C7C7CC",
            marginTop: 20, marginHorizontal: 28, lineHeight: 18,
          }}>
            {t("verifyCodeHint")}
          </Text>
        )}
      </KeyboardAvoidingView>
    </View>
    </TouchableWithoutFeedback>
  );
}
