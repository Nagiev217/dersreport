import {
  View, Text, ScrollView, TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState, useMemo } from "react";
import { useRouter } from "expo-router";
import {
  Menu, Bell, CalendarDays, ChevronRight,
  FileText, UserPlus, BookOpen,
} from "lucide-react-native";
import { auth } from "@/utils/firebase/config";
import { useStudentsStore } from "@/utils/students/store";
import { useLessonsStore } from "@/utils/lessons/store";
import { useReportsStore } from "@/utils/reports/store";
import { useVipStore, FREE_LIMIT } from "@/utils/vip/store";
import AddStudentModal from "@/components/AddStudentModal";
import VipPaywallModal from "@/components/VipPaywallModal";
import { useT } from "@/utils/i18n";

// ─── palette ─────────────────────────────────────────────────────────────────
const P = "#7068F4";          // primary purple
const G = ["#7068F4", "#9B95F8"]; // gradient
const BG = "#F2F2F7";
const CARD = "#FFFFFF";
const TEXT = "#111827";
const SUB  = "#9CA3AF";

// ─── helpers ─────────────────────────────────────────────────────────────────
const pad = (n) => String(n).padStart(2, "0");

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function getGreetingKey() {
  const h = new Date().getHours();
  if (h < 6)  return "greetingNight";
  if (h < 12) return "greetingMorning";
  if (h < 18) return "greetingDay";
  return "greetingEvening";
}

function getNextLesson(lessons) {
  const today = todayStr();
  const now   = new Date();
  const nowM  = now.getHours() * 60 + now.getMinutes();
  return lessons
    .filter(l => l.status !== "completed" && l.status !== "cancelled" && l.date)
    .filter(l => {
      if (l.date > today) return true;
      if (l.date !== today) return false;
      const [h, m] = (l.time ?? "00:00").split(":").map(Number);
      return h * 60 + m > nowM;
    })
    .sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))[0] ?? null;
}

function fmtLesson(l, todayLabel, tomorrowLabel) {
  if (!l) return null;
  const today = todayStr();
  const tom   = new Date(); tom.setDate(tom.getDate() + 1);
  const tomS  = `${tom.getFullYear()}-${pad(tom.getMonth()+1)}-${pad(tom.getDate())}`;
  const day   = l.date === today ? todayLabel : l.date === tomS ? tomorrowLabel : l.date;
  const end   = l.time && l.duration
    ? (() => { const [h,m] = l.time.split(":").map(Number); const em = h*60+m+l.duration; return `${pad(Math.floor(em/60))}:${pad(em%60)}`; })()
    : null;
  return `${day}, ${l.time}${end ? ` – ${end}` : ""}`;
}

function fmtReportTime(report, todayLabel, yesterdayLabel, shortMonths) {
  if (!report) return "";
  const today = todayStr();
  const tom   = new Date(); tom.setDate(tom.getDate() - 1);
  const ystS  = `${tom.getFullYear()}-${pad(tom.getMonth()+1)}-${pad(tom.getDate())}`;
  const d     = new Date(report.createdAt);
  const hm    = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  if (report.date === today) return `${todayLabel}${hm}`;
  if (report.date === ystS)  return `${yesterdayLabel}${hm}`;
  const mo = shortMonths;
  const [,mn,dy] = report.date.split("-").map(Number);
  return `${dy} ${mo[mn-1]}, ${hm}`;
}

const AVATAR_COLORS = [P,"#10B981","#F59E0B","#EF4444","#06B6D4","#8B5CF6","#EC4899","#0EA5E9"];
function avatarBg(name = "") {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffff;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
function initials(name = "") {
  const p = name.trim().split(/\s+/);
  return (p.length >= 2 ? p[0][0] + p[1][0] : name.slice(0, 2)).toUpperCase();
}

// ─── Main ────────────────────────────────────────────────────────────────────
export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t, tp, months } = useT();
  const [showAdd,     setShowAdd]     = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const { isVip } = useVipStore();

  const { students } = useStudentsStore();
  const { lessons }  = useLessonsStore();
  const { reports }  = useReportsStore();

  const user      = auth?.currentUser;
  const firstName = user?.displayName?.split(" ")[0] ?? t("profileTeacher");
  const today     = todayStr();
  const shortMonths   = months(true);
  const todayLabel    = t("homeTimeToday");
  const tomorrowLabel = t("tomorrow");
  const yesterdayLabel = t("homeTimeYesterday");

  const todayCount  = useMemo(() => lessons.filter(l => l.date === today && l.status !== "cancelled").length, [lessons, today]);
  const nextLesson  = useMemo(() => getNextLesson(lessons), [lessons]);
  const nextFmt     = fmtLesson(nextLesson, todayLabel, tomorrowLabel);
  const recentRpts  = useMemo(() => [...reports].sort((a,b)=>b.createdAt-a.createdAt).slice(0,2), [reports]);

  return (
    <>
      <ScrollView
        style={{ flex: 1, backgroundColor: BG }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
        showsVerticalScrollIndicator={false}
      >
        {/* ── top bar ──────────────────────────────────────────────────── */}
        <View style={{ paddingTop: insets.top + 14, paddingHorizontal: 22, flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <TouchableOpacity activeOpacity={0.7}>
            <Menu size={24} color={TEXT} strokeWidth={1.8} />
          </TouchableOpacity>
          <TouchableOpacity activeOpacity={0.7} style={{ position: "relative" }}>
            <Bell size={24} color={TEXT} strokeWidth={1.8} />
            {/* notification dot */}
            <View style={{ position: "absolute", top: 1, right: 1, width: 8, height: 8, borderRadius: 4, backgroundColor: "#3B82F6", borderWidth: 1.5, borderColor: BG }} />
          </TouchableOpacity>
        </View>

        {/* ── greeting ────────────────────────────────────────────────── */}
        <View style={{ paddingHorizontal: 22, marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontFamily: "Inter_400Regular", color: SUB, marginBottom: 2 }}>
            {t(getGreetingKey())}
          </Text>
          <Text style={{ fontSize: 34, fontFamily: "Inter_700Bold", color: TEXT, letterSpacing: -0.5, marginBottom: 4 }}>
            {firstName} 👋
          </Text>
          <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: SUB }}>
            {t("greetingSubtitle")}
          </Text>
        </View>

        {/* ── "Сегодня" gradient card ──────────────────────────────────── */}
        <View style={{ marginHorizontal: 22, marginBottom: 28 }}>
          <LinearGradient
            colors={G}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ borderRadius: 22, padding: 22, overflow: "hidden", minHeight: 120 }}
          >
            {/* watermark calendar */}
            <View style={{ position: "absolute", right: -12, bottom: -16, opacity: 0.15 }}>
              <CalendarDays size={130} color="#FFF" strokeWidth={1.2} />
            </View>

            <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: "rgba(255,255,255,0.75)", marginBottom: 16 }}>
              {t("today")}
            </Text>

            <View style={{ flexDirection: "row", gap: 36 }}>
              <View>
                <Text style={{ fontSize: 42, fontFamily: "Inter_700Bold", color: "#FFF", lineHeight: 46 }}>
                  {todayCount}
                </Text>
                <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.75)", marginTop: 2 }}>
                  {tp(todayCount, "lesson")}
                </Text>
              </View>
              <View>
                <Text style={{ fontSize: 42, fontFamily: "Inter_700Bold", color: "#FFF", lineHeight: 46 }}>
                  {students.length}
                </Text>
                <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.75)", marginTop: 2 }}>
                  {tp(students.length, "student")}
                </Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* ── Следующий урок ───────────────────────────────────────────── */}
        <View style={{ paddingHorizontal: 22, marginBottom: 28 }}>
          <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: TEXT, marginBottom: 12 }}>
            {t("homeNextLesson")}
          </Text>
          {nextLesson ? (
            <TouchableOpacity
              onPress={() => router.push(`/lesson/${nextLesson.id}`)}
              activeOpacity={0.85}
              style={{ backgroundColor: CARD, borderRadius: 18, padding: 16, flexDirection: "row", alignItems: "center", gap: 14, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 2 }, elevation: 3 }}
            >
              {/* avatar */}
              <View style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: avatarBg(nextLesson.studentNames?.[0] ?? ""), alignItems: "center", justifyContent: "center" }}>
                <Text style={{ fontSize: 14, fontFamily: "Inter_700Bold", color: "#FFF" }}>
                  {initials(nextLesson.studentNames?.[0] ?? "?")}
                </Text>
              </View>
              {/* info */}
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: TEXT, marginBottom: 2 }}>
                  {nextLesson.studentNames?.join(", ") ?? "—"}
                </Text>
                <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: SUB, marginBottom: 6 }}>
                  {nextLesson.subject ?? t("homeLesson")}
                </Text>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
                  <CalendarDays size={12} color={SUB} strokeWidth={2} />
                  <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: SUB }}>
                    {nextFmt}
                  </Text>
                </View>
              </View>
              <ChevronRight size={18} color={SUB} strokeWidth={2} />
            </TouchableOpacity>
          ) : (
            <View style={{ backgroundColor: CARD, borderRadius: 18, padding: 18, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 2 }}>
              <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: SUB }}>
                {t("homeNoLessons")}
              </Text>
            </View>
          )}
        </View>

        {/* ── Быстрые действия ─────────────────────────────────────────── */}
        <View style={{ paddingHorizontal: 22, marginBottom: 28 }}>
          <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: TEXT, marginBottom: 12 }}>
            {t("homeQuickActions")}
          </Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            {/* Новый отчёт */}
            <TouchableOpacity
              onPress={() => router.push("/report/add")}
              activeOpacity={0.85}
              style={{ flex: 1, backgroundColor: CARD, borderRadius: 18, padding: 18, alignItems: "center", gap: 12, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 2 }, elevation: 3 }}
            >
              <View style={{ width: 52, height: 52, borderRadius: 16, backgroundColor: `${P}18`, alignItems: "center", justifyContent: "center" }}>
                <FileText size={24} color={P} strokeWidth={2} />
              </View>
              <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: TEXT, textAlign: "center" }}>
                {t("homeNewReport")}
              </Text>
            </TouchableOpacity>

            {/* Добавить ученика */}
            <TouchableOpacity
              onPress={() => { if (students.length >= FREE_LIMIT && !isVip) setShowPaywall(true); else setShowAdd(true); }}
              activeOpacity={0.85}
              style={{ flex: 1, backgroundColor: CARD, borderRadius: 18, padding: 18, alignItems: "center", gap: 12, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 2 }, elevation: 3 }}
            >
              <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: "#10B98118", alignItems: "center", justifyContent: "center" }}>
                <UserPlus size={24} color="#10B981" strokeWidth={2} />
              </View>
              <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: TEXT, textAlign: "center" }}>
                {t("homeAddStudent")}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* ── Недавние отчёты ──────────────────────────────────────────── */}
        {recentRpts.length > 0 && (
          <View style={{ paddingHorizontal: 22 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: TEXT }}>
                {t("homeRecentReports")}
              </Text>
              <TouchableOpacity onPress={() => router.navigate("/(tabs)/reports")} activeOpacity={0.7}>
                <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: P }}>
                  {t("homeViewAll")}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={{ backgroundColor: CARD, borderRadius: 18, overflow: "hidden", shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 2 }, elevation: 3 }}>
              {recentRpts.map((r, i) => {
                const bg = avatarBg(r.studentName ?? "");
                return (
                  <TouchableOpacity
                    key={r.id}
                    onPress={() => router.push(`/report/${r.id}`)}
                    activeOpacity={0.75}
                    style={{
                      flexDirection: "row", alignItems: "center", gap: 14,
                      padding: 16,
                      borderBottomWidth: i < recentRpts.length - 1 ? 1 : 0,
                      borderBottomColor: "#F3F4F6",
                    }}
                  >
                    {/* avatar */}
                    <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: bg, alignItems: "center", justifyContent: "center" }}>
                      <Text style={{ fontSize: 13, fontFamily: "Inter_700Bold", color: "#FFF" }}>
                        {initials(r.studentName ?? "?")}
                      </Text>
                    </View>
                    {/* info */}
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: TEXT, marginBottom: 2 }}>
                        {r.studentName ?? "—"}
                      </Text>
                      <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: SUB }}>
                        {fmtReportTime(r, todayLabel, yesterdayLabel, shortMonths)}
                      </Text>
                    </View>
                    {/* icon */}
                    <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: `${P}12`, alignItems: "center", justifyContent: "center" }}>
                      <FileText size={16} color={P} strokeWidth={2} />
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        )}
      </ScrollView>

      <AddStudentModal visible={showAdd} onClose={() => setShowAdd(false)} />
      <VipPaywallModal
        visible={showPaywall}
        onClose={() => setShowPaywall(false)}
        onUpgraded={() => setShowPaywall(false)}
      />
    </>
  );
}
